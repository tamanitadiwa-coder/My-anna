import { createAndShareBackup, pickBackup, restoreFromPayload } from '../backup/backupFiles';
import { extractBrainOnly } from '../backup/backupCore';
import { logEvent } from './brainService';
export const exportBrain = () => createAndShareBackup('brain', 'export');
export const backupBrain = () => createAndShareBackup('full', 'backup');
/** Returns null if the user cancelled the picker. Throws a readable error if the file is bad. */
export async function pickBrainBackup() { return pickBackup(); }
/** True if the file also contains chats, tasks, money or business data (which a Brain restore will ignore). */
export const hasMoreThanBrain = (payload: any) => payload?.scope === 'full';
/**
 * Brain-only restore. Whatever file is given (a Brain export or a full backup), ONLY memories, feedback and Brain history
 * are restored; chats, tasks, money and business data are never touched. A safety copy of everything is saved first.
 */
export async function restoreBrain(payload: any, mode: 'merge' | 'replace') {
  const counts = await restoreFromPayload(extractBrainOnly(payload), mode); await logEvent('restore', `Brain restored from backup (${mode})`); return counts;
}
