// Decorative only. Every statistic on the screen comes from the database, not from this.
import React, { useEffect, useRef } from 'react';
import { Animated, Easing } from 'react-native';
import Svg, { Circle, Line, Ellipse } from 'react-native-svg';

const AC = Animated.createAnimatedComponent(Circle);
const NODES = Array.from({ length: 22 }, (_, i) => {
  const a = (i / 22) * Math.PI * 2, r = 0.55 + ((i * 37) % 10) / 28;
  return { x: 110 + Math.cos(a) * 78 * r, y: 80 + Math.sin(a) * 52 * r };
});
const EDGES = NODES.flatMap((n, i) => [1, 5].map(k => [n, NODES[(i + k) % NODES.length]]));

export default function NeuralBrain({ size = 220, activity = 0 }: { size?: number; activity?: number }) {
  const pulse = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1, duration: 2600, easing: Easing.inOut(Easing.sin), useNativeDriver: false }),
      Animated.timing(pulse, { toValue: 0, duration: 2600, easing: Easing.inOut(Easing.sin), useNativeDriver: false }),
    ]));
    loop.start(); return () => loop.stop();
  }, [pulse]);
  const r = pulse.interpolate({ inputRange: [0, 1], outputRange: [3, 4.6] });
  const lit = Math.min(NODES.length, 4 + activity); // more saved memories → more lit nodes
  return (
    <Svg width={size} height={size * 0.75} viewBox="0 0 220 160">
      <Ellipse cx="110" cy="80" rx="92" ry="64" fill="#E6EEE3" opacity={0.7} />
      {EDGES.map(([a, b], i) => <Line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#9FB8A3" strokeWidth={0.8} opacity={0.6} />)}
      {NODES.map((n, i) => <AC key={i} cx={n.x} cy={n.y} r={i < lit ? r : 2.6} fill={i < lit ? '#7E9C84' : '#A9C3D9'} />)}
    </Svg>
  );
}
