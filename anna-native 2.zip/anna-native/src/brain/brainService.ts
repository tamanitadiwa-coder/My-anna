// ANNA'S BRAIN — local-only data layer. No network. Uses the app's single shared database.
import type { Db } from '../db/types';
import { createBackup, restoreWithSafetyNet, wipeAll, BackupPayload } from '../backup/backupCore';

export type MemoryStatus = 'confirmed' | 'temporary' | 'assumption';
export type CategoryKey = 'about' | 'preferences' | 'finances' | 'business' | 'goals' | 'routines' | 'people' | 'dates' | 'instructions';
export const CATEGORIES: { key: CategoryKey; label: string }[] = [
  { key: 'about', label: 'About me' }, { key: 'preferences', label: 'My preferences' },
  { key: 'finances', label: 'My finances' }, { key: 'business', label: 'My business' },
  { key: 'goals', label: 'My goals' }, { key: 'routines', label: 'My routines' },
  { key: 'people', label: 'Important people' }, { key: 'dates', label: 'Important dates' },
  { key: 'instructions', label: 'Instructions I taught Anna' },
];
const CAT_KEYS = CATEGORIES.map(c => c.key as string);
const STATUSES = ['confirmed', 'temporary', 'assumption'];
const RATINGS = ['helpful', 'not_helpful', 'incorrect', 'remember', 'dont_remember'] as const;
export type Rating = typeof RATINGS[number];
export const MAX_MEMORY_CHARS = 2000;

export interface Memory {
  id: string; category: CategoryKey; content: string; status: MemoryStatus;
  source: 'taught' | 'manual' | 'feedback' | 'inferred';
  created_at: number; updated_at: number; expires_at: number | null;
  use_count: number; helpful_count: number; incorrect_count: number; last_used_at: number | null;
}
export interface BrainEvent { id: string; type: string; title: string; detail: string | null; created_at: number }

/** Hooks the app sets once at startup. Table names default to the ones Anna really has. */
export const brainConfig = {
  taskTables: ['tasks'] as string[],
  recordTables: ['transactions', 'bills', 'budgets', 'business_records'] as string[],
  getModelStatus: (async () => 'unavailable') as () => Promise<'downloaded' | 'loading' | 'ready' | 'unavailable'>,
  getModelName: (async () => null) as () => Promise<string | null>,
  getStorage: (async () => ({ dbBytes: null, freeBytes: null })) as () => Promise<{ dbBytes: number | null; freeBytes: number | null }>,
};

let _db: Db | null = null;
export function setBrainDb(db: Db) { _db = db; }
function db(): Db { if (!_db) throw new Error('Brain database is not ready yet.'); return _db; }
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const now = () => Date.now();
const DAY = 86400000;
const catLabel = (k: string) => CATEGORIES.find(c => c.key === k)?.label ?? k;

export async function initBrain() {
  const d = db();
  const started = await d.getFirstAsync(`SELECT 1 FROM brain_meta WHERE key='started'`);
  if (!started) {
    await d.runAsync(`INSERT INTO brain_meta VALUES('started',?)`, String(now()));
    await logEvent('brain_created', 'Anna’s Brain created');
  }
  const exp = await d.runAsync(`DELETE FROM brain_memories WHERE expires_at IS NOT NULL AND expires_at < ?`, now());
  if (exp.changes > 0) await logEvent('memory_expired', `${exp.changes} temporary memor${exp.changes === 1 ? 'y' : 'ies'} expired`);
  await syncModelEvent();
}

// Events never contain memory text, so deleting a memory really removes it everywhere.
export async function logEvent(type: string, title: string, detail?: string) {
  await db().runAsync(`INSERT INTO brain_events VALUES(?,?,?,?,?)`, uid(), type, title, detail ?? null, now());
}
async function syncModelEvent() {
  const d = db(); const status = await brainConfig.getModelStatus();
  const last = await d.getFirstAsync<{ value: string }>(`SELECT value FROM brain_meta WHERE key='model_status'`);
  if (last?.value !== status) {
    await d.runAsync(`INSERT OR REPLACE INTO brain_meta VALUES('model_status',?)`, status);
    await logEvent('model_status', `AI model ${status}`, (await brainConfig.getModelName()) ?? undefined);
  }
}

// ---- Memories --------------------------------------------------------------
export class ValidationError extends Error {}
function cleanContent(s: string) {
  const t = (s ?? '').trim();
  if (!t) throw new ValidationError('Please write something to save.');
  if (t.length > MAX_MEMORY_CHARS) throw new ValidationError(`Memories can be up to ${MAX_MEMORY_CHARS} characters.`);
  return t;
}

export async function addMemory(p: { category: CategoryKey; content: string; status: MemoryStatus; source?: Memory['source']; ttlDays?: number }) {
  if (!CAT_KEYS.includes(p.category)) throw new ValidationError('Unknown category.');
  if (!STATUSES.includes(p.status)) throw new ValidationError('Unknown status.');
  const content = cleanContent(p.content); const d = db();
  // Duplicate-submission protection: the same text in the same category is saved once.
  const dup = await d.getFirstAsync<{ id: string }>(`SELECT id FROM brain_memories WHERE category=? AND lower(content)=lower(?)`, p.category, content);
  if (dup) return dup.id;
  const id = uid(); const t = now();
  const expires = p.status === 'temporary' ? t + (p.ttlDays ?? 7) * DAY : null;
  await d.runAsync(`INSERT INTO brain_memories VALUES(?,?,?,?,?,?,?,?,0,0,0,NULL)`, id, p.category, content, p.status, p.source ?? 'manual', t, t, expires);
  await logEvent(p.category === 'instructions' ? 'instruction_taught' : 'memory_added',
    p.category === 'instructions' ? 'Learned a new instruction' : `Saved a ${p.status} memory`, catLabel(p.category));
  return id;
}

export async function updateMemory(id: string, p: Partial<Pick<Memory, 'content' | 'category' | 'status'>>) {
  const d = db(); const cur = await d.getFirstAsync<Memory>(`SELECT * FROM brain_memories WHERE id=?`, id);
  if (!cur) throw new ValidationError('That memory no longer exists.');
  if (p.category && !CAT_KEYS.includes(p.category)) throw new ValidationError('Unknown category.');
  if (p.status && !STATUSES.includes(p.status)) throw new ValidationError('Unknown status.');
  const status = p.status ?? cur.status;
  const expires = status === 'temporary' ? (cur.expires_at ?? now() + 7 * DAY) : null;
  await d.runAsync(`UPDATE brain_memories SET content=?, category=?, status=?, expires_at=?, updated_at=? WHERE id=?`,
    p.content !== undefined ? cleanContent(p.content) : cur.content, p.category ?? cur.category, status, expires, now(), id);
  await logEvent('memory_updated', status !== cur.status ? `Memory marked ${status}` : 'Memory edited');
}
export async function deleteMemory(id: string) {
  const r = await db().runAsync(`DELETE FROM brain_memories WHERE id=?`, id);
  if (r.changes) await logEvent('memory_deleted', 'Memory deleted');
}
export async function clearMemories(ids: string[]) {
  if (!ids.length) return 0;
  let n = 0;
  await db().withTransactionAsync(async () => {
    for (const id of ids) n += (await db().runAsync(`DELETE FROM brain_memories WHERE id=?`, id)).changes;
    if (n) await logEvent('memory_deleted', `${n} memor${n === 1 ? 'y' : 'ies'} cleared`);
  });
  return n;
}
export async function listMemories(opts: { category?: CategoryKey; q?: string } = {}) {
  const where: string[] = []; const args: any[] = [];
  if (opts.category) { where.push('category=?'); args.push(opts.category); }
  if (opts.q?.trim()) { where.push(`content LIKE ? ESCAPE '\\'`); args.push(`%${opts.q.trim().replace(/[\\%_]/g, m => '\\' + m)}%`); }
  return db().getAllAsync<Memory>(`SELECT * FROM brain_memories ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY updated_at DESC`, ...args);
}

// ---- Teach Anna: propose first, save only after the user says yes ----------
export interface TeachProposal { content: string; category: CategoryKey; suggestedStatus: MemoryStatus }
export function proposeFromText(text: string): TeachProposal {
  const t = text.toLowerCase(); let category: CategoryKey = 'about';
  if (/^(when i|always|never|whenever|please always|don.t ever)/.test(t)) category = 'instructions';
  else if (/(bill|spend|budget|salary|money|rent|savings|debt|pay)/.test(t)) category = 'finances';
  else if (/(business|sales|customer|client|revenue|profit|shop|brand)/.test(t)) category = 'business';
  else if (/(goal|want to achieve|aim|target|plan to)/.test(t)) category = 'goals';
  else if (/(every (day|morning|week|night)|morning|evening|routine|wake|sleep|gym)/.test(t)) category = 'routines';
  else if (/(birthday|anniversary|deadline|due on|on the \d)/.test(t)) category = 'dates';
  else if (/(my (mom|mother|dad|father|sister|brother|wife|husband|partner|friend|boss))/.test(t)) category = 'people';
  else if (/(i prefer|i like|i love|i hate|i don.t like|favourite|favorite)/.test(t)) category = 'preferences';
  const hedged = /(maybe|probably|i think|might|not sure|perhaps)/.test(t);
  const temp = /(this week|today|tomorrow|for now|right now|this month)/.test(t);
  return { content: text.trim(), category, suggestedStatus: hedged ? 'assumption' : temp ? 'temporary' : 'confirmed' };
}

// ---- Retrieval --------------------------------------------------------------
const STOP = new Set('the a an and or but of to in on at for with my me i is are was be it that this how much can what when do does'.split(' '));
const tok = (s: string) => s.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(w => w.length > 2 && !STOP.has(w));

export async function retrieveRelevant(query: string, limit = 6) {
  const all = await listMemories(); const q = new Set(tok(query));
  const scored = all.map(m => {
    const overlap = tok(m.content).filter(w => q.has(w)).length; const instr = m.category === 'instructions';
    const score = overlap * 2 + (instr ? 2 : 0) + (m.status === 'confirmed' ? 1 : 0) + Math.min(m.helpful_count, 3) * 0.5 - m.incorrect_count * 1.5;
    return { m, score, eligible: overlap > 0 || instr };
  }).filter(x => x.eligible && x.score > 0).sort((a, b) => b.score - a.score).slice(0, limit);
  for (const { m } of scored) await db().runAsync(`UPDATE brain_memories SET use_count=use_count+1,last_used_at=? WHERE id=?`, now(), m.id);
  return scored.map(x => x.m);
}
export function buildPromptContext(mems: Memory[]) {
  if (!mems.length) return '';
  const lines = mems.map(m => `- [${m.category}/${m.status === 'confirmed' ? 'CONFIRMED' : m.status === 'temporary' ? 'TEMPORARY' : 'UNCONFIRMED ASSUMPTION - verify, do not state as fact'}] ${m.content}`);
  return `What you know about the user (saved on their phone):\n${lines.join('\n')}\nFollow CONFIRMED instructions. Never present assumptions as facts.`;
}

// ---- Feedback ---------------------------------------------------------------
export async function recordFeedback(p: { rating: Rating; messageId?: string; memoryIds?: string[]; answerText?: string }) {
  if (!RATINGS.includes(p.rating)) throw new ValidationError('Unknown rating.');
  const d = db(); const ids = p.memoryIds ?? [];
  await d.withTransactionAsync(async () => {
    await d.runAsync(`INSERT INTO brain_feedback VALUES(?,?,?,?,?)`, uid(), p.messageId ?? null, p.rating, JSON.stringify(ids), now());
    for (const id of ids) {
      if (p.rating === 'helpful') await d.runAsync(`UPDATE brain_memories SET helpful_count=helpful_count+1 WHERE id=?`, id);
      if (p.rating === 'incorrect') await d.runAsync(`UPDATE brain_memories SET incorrect_count=incorrect_count+1 WHERE id=?`, id);
      if (p.rating === 'dont_remember') await d.runAsync(`DELETE FROM brain_memories WHERE id=? AND status!='confirmed'`, id);
    }
    await logEvent('feedback', `Feedback: ${p.rating.replace('_', ' ')}`);
  });
  return p.rating === 'remember' && p.answerText ? proposeFromText(p.answerText) : null;
}

// ---- Stats (every figure is a real query) ----------------------------------
async function tableExists(n: string) { return !!(await db().getFirstAsync(`SELECT 1 FROM sqlite_master WHERE type='table' AND name=?`, n)); }
async function sumTables(names: string[]): Promise<number | null> {
  let total = 0, found = false;
  for (const n of names) if (/^[a-z_]+$/i.test(n) && await tableExists(n)) { found = true; total += (await db().getFirstAsync<{ c: number }>(`SELECT COUNT(*) c FROM ${n}`))!.c; }
  return found ? total : null;
}
async function taskCounts() {
  let total = 0, done = 0, found = false;
  for (const n of brainConfig.taskTables) if (/^[a-z_]+$/i.test(n) && await tableExists(n)) {
    found = true;
    const cols = (await db().getAllAsync<{ name: string }>(`PRAGMA table_info(${n})`)).map(c => c.name);
    total += (await db().getFirstAsync<{ c: number }>(`SELECT COUNT(*) c FROM ${n}`))!.c;
    if (cols.includes('completed')) done += (await db().getFirstAsync<{ c: number }>(`SELECT COUNT(*) c FROM ${n} WHERE completed=1`))!.c;
  }
  return found ? { total, done } : null;
}
const cnt = async (sql: string, ...a: any[]) => (await db().getFirstAsync<{ c: number }>(sql, ...a))!.c;

export async function getStats() {
  const d = db(); await syncModelEvent();
  const lastMem = await d.getFirstAsync<{ t: number | null }>(`SELECT MAX(updated_at) t FROM brain_memories`);
  const lastBk = (await d.getFirstAsync<{ value: string }>(`SELECT value FROM brain_meta WHERE key='last_backup'`))?.value;
  const storage = await brainConfig.getStorage();
  return {
    modelStatus: await brainConfig.getModelStatus(), modelName: await brainConfig.getModelName(),
    memories: await cnt(`SELECT COUNT(*) c FROM brain_memories`),
    confirmed: await cnt(`SELECT COUNT(*) c FROM brain_memories WHERE status='confirmed'`),
    temporary: await cnt(`SELECT COUNT(*) c FROM brain_memories WHERE status='temporary'`),
    assumptions: await cnt(`SELECT COUNT(*) c FROM brain_memories WHERE status='assumption'`),
    preferences: await cnt(`SELECT COUNT(*) c FROM brain_memories WHERE category IN ('preferences','instructions') AND status='confirmed'`),
    conversations: await sumTables(['conversations']), tasks: await taskCounts(), records: await sumTables(brainConfig.recordTables),
    lastMemoryUpdate: lastMem?.t ?? null, lastBackup: lastBk ? Number(lastBk) : null,
    dbBytes: storage.dbBytes, freeBytes: storage.freeBytes,
  };
}

export interface Progress { key: string; label: string; value: number | null; evidence: string }
const GOAL = 10;
export async function getProgress(): Promise<Progress[]> {
  const s = await getStats();
  const byCat = (c: string) => cnt(`SELECT COUNT(*) c FROM brain_memories WHERE category=? AND status='confirmed'`, c);
  const fb = await cnt(`SELECT COUNT(*) c FROM brain_feedback WHERE rating IN ('helpful','not_helpful','incorrect')`);
  const good = await cnt(`SELECT COUNT(*) c FROM brain_feedback WHERE rating='helpful'`);
  const cov = (n: number, what: string) => n === 0 ? { value: null as number | null, evidence: `No ${what} saved yet` }
    : { value: Math.min(n / GOAL, 1), evidence: `${n} ${what} saved (bar fills at ${GOAL})` };
  const prefs = (await byCat('preferences')) + (await byCat('instructions')) + (await byCat('about'));
  const used = await cnt(`SELECT COUNT(*) c FROM brain_memories WHERE use_count>0`);
  const helpMem = await cnt(`SELECT COUNT(*) c FROM brain_memories WHERE helpful_count>0`);
  const finN = (await byCat('finances')) + (s.records ?? 0);
  const biz = (await byCat('business')) + (await byCat('goals'));
  return [
    { key: 'prefs', label: 'Understanding my preferences', ...cov(prefs, 'preferences & facts') },
    { key: 'mem', label: 'Remembering important information',
      ...(used === 0 ? { value: null, evidence: `${s.confirmed} confirmed memories; none retrieved yet` }
        : { value: helpMem / used, evidence: `${helpMem} of ${used} retrieved memories rated helpful` }) },
    { key: 'routine', label: 'Understanding my daily routines', ...cov(await byCat('routines'), 'routines') },
    { key: 'fin', label: 'Understanding my financial habits', ...cov(finN, 'finance memories/records') },
    { key: 'biz', label: 'Understanding my business', ...cov(biz, 'business & goal memories') },
    { key: 'tasks', label: 'Helping me organise tasks',
      ...(!s.tasks || s.tasks.total === 0 ? { value: null, evidence: 'No tasks yet' } : { value: s.tasks.done / s.tasks.total, evidence: `${s.tasks.done} of ${s.tasks.total} tasks completed` }) },
    { key: 'recs', label: 'Giving useful recommendations',
      ...(fb < 5 ? { value: null, evidence: `Needs ${5 - fb} more rating${fb === 4 ? '' : 's'} to measure (${fb} so far)` } : { value: good / fb, evidence: `${good} of ${fb} rated answers were helpful` }) },
  ];
}
export async function getTimeline(limit = 100) {
  const d = db();
  const start = Number((await d.getFirstAsync<{ value: string }>(`SELECT value FROM brain_meta WHERE key='started'`))?.value ?? now());
  const rows = await d.getAllAsync<BrainEvent>(`SELECT * FROM brain_events ORDER BY created_at DESC LIMIT ?`, limit);
  return rows.map(e => ({ ...e, day: Math.max(1, Math.floor((e.created_at - start) / DAY) + 1) }));
}

// ---- Backup hooks used by the app's backup system ---------------------------
export const getBrainBackupPayload = (): Promise<BackupPayload> => createBackup(db(), 'brain');
/**
 * Restores Brain data from a backup. Always saves a safety snapshot of everything first (if the snapshot cannot be
 * saved, nothing is changed), so there is no unsafe way to call it. Pass a Brain-only payload
 * (see extractBrainOnly in backupCore) to guarantee chats, tasks and money are never touched.
 */
export async function restoreBrainPayload(p: unknown, mode: 'merge' | 'replace', saveSnapshot: (snapshot: BackupPayload) => Promise<void>) {
  const counts = await restoreWithSafetyNet(db(), p, mode, saveSnapshot);
  await logEvent('restore', `Brain restored (${mode})`);
  return counts;
}
export async function markBackupDone(kind: 'backup' | 'export') {
  if (kind === 'backup') await db().runAsync(`INSERT OR REPLACE INTO brain_meta VALUES('last_backup',?)`, String(now()));
  await logEvent(kind, kind === 'backup' ? 'Backup created' : 'Brain memories exported');
}

// ---- Privacy controls (all transactional) -----------------------------------
export async function clearConversationHistory() {
  await db().withTransactionAsync(async () => {
    await db().runAsync(`DELETE FROM messages`); await db().runAsync(`DELETE FROM conversations`);
    await db().runAsync(`DELETE FROM brain_feedback WHERE message_id IS NOT NULL`);
    await logEvent('privacy', 'Conversation history cleared');
  });
}
/** Removes learned preferences, routines, instructions, feedback and usage counters. Other facts stay. */
export async function resetPersonalisation() {
  await db().withTransactionAsync(async () => {
    await db().runAsync(`DELETE FROM brain_memories WHERE category IN ('preferences','instructions','routines')`);
    await db().runAsync(`DELETE FROM brain_feedback`);
    await db().runAsync(`UPDATE brain_memories SET use_count=0,helpful_count=0,incorrect_count=0,last_used_at=NULL`);
    await logEvent('reset', 'Personalisation reset');
  });
}
export async function deleteAllAnnaData() { await wipeAll(db()); await initBrain(); }
