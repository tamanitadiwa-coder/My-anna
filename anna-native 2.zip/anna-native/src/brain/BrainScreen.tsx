import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Modal, Platform, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import NeuralBrain from './NeuralBrain';
import { C } from '../theme';
import * as B from './brainService';
import * as F from './brainFiles';
import { dataEvents } from '../util/events';
import { CATEGORIES, CategoryKey, Memory, MemoryStatus, TeachProposal } from './brainService';

const serif = Platform.select({ ios: 'Georgia', default: 'serif' });
const fmt = (t: number | null) => t ? new Date(t).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'Never';
const bytes = (n: number | null) => n == null ? 'Not measurable' : n > 1e9 ? `${(n / 1e9).toFixed(1)} GB` : `${(n / 1e6).toFixed(1)} MB`;
const STATUS: Record<MemoryStatus, { label: string; bg: string; fg: string }> = {
  confirmed: { label: 'Confirmed fact', bg: C.sageSoft, fg: C.sageDark },
  temporary: { label: 'Temporary', bg: C.blueSoft, fg: '#3F6A8A' },
  assumption: { label: 'Assumption', bg: '#F5E6D3', fg: C.warn },
};

export default function BrainScreen() {
  const [stats, setStats] = useState<any>(null);
  const [progress, setProgress] = useState<B.Progress[]>([]);
  const [timeline, setTimeline] = useState<any[]>([]);
  const [mems, setMems] = useState<Memory[]>([]);
  const [q, setQ] = useState('');
  const [open, setOpen] = useState<CategoryKey | null>(null);
  const [teach, setTeach] = useState('');
  const [proposal, setProposal] = useState<TeachProposal | null>(null);
  const [editing, setEditing] = useState<Memory | null>(null);
  const [layer, setLayer] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);
  const [ready, setReady] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const [selecting, setSelecting] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [loadError, setLoadError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setStats(await B.getStats()); setProgress(await B.getProgress());
      setTimeline(await B.getTimeline()); setMems(await B.listMemories({ q })); setLoadError(null);
    } catch (e: any) { setLoadError(e?.message ?? String(e)); }
  }, [q]);
  useEffect(() => { B.initBrain().then(() => setReady(true)).catch((e: any) => setLoadError(e?.message ?? String(e))); }, []);
  useEffect(() => dataEvents.subscribe(() => { load(); }), [load]);
  useEffect(() => { if (ready) load(); }, [ready, load]);

  const run = async (fn: () => Promise<any>, ok?: string) => {
    if (busyRef.current) return; // ignore double taps while an action is running
    busyRef.current = true; setBusy(true);
    try { await fn(); if (ok) Alert.alert(ok); } catch (e: any) { Alert.alert('Something went wrong', e?.message ?? String(e)); }
    busyRef.current = false; setBusy(false); load();
  };
  const confirm = (title: string, msg: string, action: string, fn: () => Promise<any>, ok?: string) =>
    Alert.alert(title, msg, [{ text: 'Cancel', style: 'cancel' }, { text: action, style: 'destructive', onPress: () => run(fn, ok) }]);

  if (loadError && !stats) return <View style={[s.root, { justifyContent: 'center', padding: 24 }]}><Text style={s.h2}>Brain could not load</Text><Text style={s.body}>{loadError}</Text><Btn label="Try again" onPress={() => { B.initBrain().then(() => setReady(true)).catch((e: any) => setLoadError(e?.message ?? String(e))); }} /></View>;
  if (!ready || !stats) return <View style={[s.root, { justifyContent: 'center' }]}><ActivityIndicator color={C.sage} /></View>;
  const modelColor = { ready: C.sage, loading: C.blue, downloaded: C.blue, unavailable: C.warn }[stats.modelStatus as string];

  return (
    <ScrollView style={s.root} contentContainerStyle={{ padding: 18, paddingBottom: 60 }}
      refreshControl={<RefreshControl refreshing={busy} onRefresh={load} tintColor={C.sage} />}>
      <Text style={s.h1}>Anna’s Brain</Text>
      <Text style={s.sub}>How well Anna knows you, what she has learned, and how she is improving. Everything stays on this iPhone.</Text>
      <View style={{ alignItems: 'center', marginVertical: 6 }}><NeuralBrain activity={stats.confirmed} /></View>

      {/* 1. Dashboard */}
      <View style={s.card}>
        <View style={s.row}><View style={[s.dot, { backgroundColor: modelColor }]} />
          <Text style={s.cardTitle}>AI model: {stats.modelStatus}</Text></View>
        <Text style={s.mute}>{stats.modelName ?? 'No model name reported'}</Text>
      </View>
      <View style={s.grid}>
        <Stat n={stats.memories} l="Saved memories" /><Stat n={stats.preferences} l="Preferences learned" />
        <Stat n={stats.conversations} l="Conversations" /><Stat n={stats.tasks?.total ?? null} l="Tasks organised" />
        <Stat n={stats.records} l="Finance & business records" /><Stat n={stats.assumptions} l="Unconfirmed assumptions" />
      </View>
      <View style={s.card}>
        <Line k="Memory storage used" v={bytes(stats.dbBytes)} /><Line k="Phone storage free" v={bytes(stats.freeBytes)} />
        <Line k="Last memory update" v={fmt(stats.lastMemoryUpdate)} /><Line k="Last backup" v={fmt(stats.lastBackup)} />
      </View>

      {/* 2. Progress */}
      <Text style={s.h2}>What Anna has learned</Text>
      <View style={s.card}>
        {progress.map(p => (
          <View key={p.key} style={{ marginBottom: 14 }}>
            <View style={s.rowBetween}><Text style={s.label}>{p.label}</Text>
              <Text style={s.mute}>{p.value == null ? 'No data yet' : `${Math.round(p.value * 100)}%`}</Text></View>
            <View style={s.track}><View style={[s.fill, { width: `${(p.value ?? 0) * 100}%` }]} /></View>
            <Text style={s.tiny}>{p.evidence}</Text>
          </View>))}
        <Text style={s.tiny}>Bars show real counts and your ratings only. They are not an intelligence score.</Text>
      </View>

      {/* 7. Four layers */}
      <Text style={s.h2}>What is actually improving</Text>
      {LAYERS.map(l => (
        <Pressable key={l.k} style={s.card} onPress={() => setLayer(layer === l.k ? null : l.k)}>
          <View style={s.rowBetween}><Text style={s.cardTitle}>{l.t}</Text><Text style={s.mute}>{layer === l.k ? '–' : '+'}</Text></View>
          {layer === l.k && <Text style={[s.body, { marginTop: 6 }]}>{l.d}</Text>}
        </Pressable>))}

      {/* 3. Teach */}
      <Text style={s.h2}>Teach Anna</Text>
      <View style={s.card}>
        <TextInput style={s.input} multiline value={teach} onChangeText={setTeach} placeholderTextColor={C.mute}
          placeholder="e.g. I prefer paying my bills at the beginning of the month." />
        <Btn label="Review what to save" onPress={() => teach.trim() && setProposal(B.proposeFromText(teach))} />
        {proposal && (
          <View style={{ marginTop: 12 }}>
            <Text style={s.label}>Save this as a permanent memory?</Text>
            <Text style={[s.body, { marginVertical: 6 }]}>“{proposal.content}”</Text>
            <Text style={s.tiny}>Category</Text>
            <View style={s.chips}>{CATEGORIES.map(c => (
              <Chip key={c.key} label={c.label} on={proposal.category === c.key} onPress={() => setProposal({ ...proposal, category: c.key })} />))}</View>
            <Text style={s.tiny}>Anna suggests: {STATUS[proposal.suggestedStatus].label}</Text>
            <View style={s.rowWrap}>
              <Btn label="Save permanently" onPress={() => run(async () => { await B.addMemory({ ...proposal, status: 'confirmed', source: 'taught' }); setProposal(null); setTeach(''); })} />
              <Btn ghost label="Temporary (7 days)" onPress={() => run(async () => { await B.addMemory({ ...proposal, status: 'temporary', source: 'taught' }); setProposal(null); setTeach(''); })} />
              <Btn ghost label="Don’t save" onPress={() => setProposal(null)} />
            </View>
          </View>)}
      </View>

      {/* 4. Memory centre */}
      <Text style={s.h2}>Memory centre</Text>
      <TextInput style={[s.input, { backgroundColor: C.card }]} value={q} onChangeText={setQ} placeholder="Search memories" placeholderTextColor={C.mute} />
      {CATEGORIES.map(c => {
        const list = mems.filter(m => m.category === c.key);
        return (
          <View key={c.key} style={s.card}>
            <Pressable style={s.rowBetween} onPress={() => setOpen(open === c.key ? null : c.key)}>
              <Text style={s.cardTitle}>{c.label}</Text><Text style={s.mute}>{list.length}  {open === c.key ? '–' : '+'}</Text></Pressable>
            {(open === c.key || showAll || q.trim() !== '') && list.map(m => (
              <Pressable key={m.id} style={[s.mem, selecting && selected.has(m.id) && { backgroundColor: C.blueSoft }]}
                onPress={() => selecting ? setSelected(prev => { const n = new Set(prev); n.has(m.id) ? n.delete(m.id) : n.add(m.id); return n; }) : setEditing(m)}>
                <Text style={s.body}>{m.content}</Text>
                <View style={[s.rowBetween, { marginTop: 6 }]}>
                  <View style={[s.badge, { backgroundColor: STATUS[m.status].bg }]}><Text style={{ color: STATUS[m.status].fg, fontSize: 11 }}>{STATUS[m.status].label}</Text></View>
                  <Text style={s.tiny}>{m.updated_at !== m.created_at ? `Updated ${fmt(m.updated_at)}` : `Created ${fmt(m.created_at)}`}</Text>
                </View>
              </Pressable>))}
            {open === c.key && list.length === 0 && <Text style={[s.tiny, { marginTop: 8 }]}>Nothing saved here yet. Use Teach Anna above.</Text>}
          </View>);
      })}

      {/* 6. Timeline */}
      <Text style={s.h2}>Learning timeline</Text>
      <View style={s.card}>
        {timeline.length === 0 && <Text style={s.mute}>Events will appear here as Anna learns.</Text>}
        {timeline.map(e => (
          <View key={e.id} style={s.tl}><View style={s.tlDot} />
            <View style={{ flex: 1 }}><Text style={s.label}>Day {e.day}: {e.title}</Text>
              {!!e.detail && <Text style={s.tiny} numberOfLines={2}>{e.detail}</Text>}
              <Text style={s.tiny}>{fmt(e.created_at)}</Text></View></View>))}
      </View>

      {/* 8. Privacy */}
      <Text style={s.h2}>Privacy & control</Text>
      <View style={s.card}>
        <Btn ghost label="Export brain memories" onPress={() => run(F.exportBrain)} />
        <Btn ghost label="Full backup (chats, Brain, tasks, money)" onPress={() => run(F.backupBrain, 'Backup created')} />
        <Btn ghost label="Restore Brain from a backup file" onPress={async () => {
          try {
            const payload = await F.pickBrainBackup(); if (!payload) return;
            const extra = F.hasMoreThanBrain(payload) ? 'This file also contains chats, tasks and money. Only Anna’s Brain (memories, feedback, history) will be restored; everything else stays exactly as it is. ' : '';
            Alert.alert('Restore Brain', extra + 'Anna saves a safety copy of all your data first. Merge adds missing items and keeps anything you changed more recently. Replace swaps the Brain for the backup.', [
              { text: 'Cancel', style: 'cancel' },
              { text: 'Merge', onPress: () => run(async () => { await F.restoreBrain(payload, 'merge'); dataEvents.emit(); }, 'Restored') },
              { text: 'Replace', style: 'destructive', onPress: () => run(async () => { await F.restoreBrain(payload, 'replace'); dataEvents.emit(); }, 'Restored') }]);
          } catch (e: any) { Alert.alert('Cannot restore', e?.message ?? String(e)); }
        }} />
        <Btn ghost label="View all saved information" onPress={() => { setShowAll(true); setQ(''); }} />
        <Btn ghost label="Clear conversation history" onPress={() => confirm('Clear conversations?', 'Chat history will be removed. Memories stay.', 'Clear', async () => { await B.clearConversationHistory(); dataEvents.emit(); }, 'Cleared')} />
        <Btn ghost label={selecting ? 'Cancel selecting' : 'Select memories to clear'} onPress={() => { setSelecting(!selecting); setSelected(new Set()); setShowAll(true); }} />
        {selecting && <Btn danger label={`Delete ${selected.size} selected`} onPress={() => selected.size
          ? confirm('Delete selected memories?', `${selected.size} memor${selected.size === 1 ? 'y' : 'ies'} will be forgotten. This cannot be undone.`, 'Delete',
              async () => { await B.clearMemories([...selected]); setSelected(new Set()); setSelecting(false); })
          : Alert.alert('Nothing selected', 'Tap the memories above that you want to delete, then press this button.')} />}
        <Btn ghost label="Reset personalisation" onPress={() => confirm('Reset personalisation?', 'Removes learned preferences, routines, instructions and feedback. Facts about you stay.', 'Reset', B.resetPersonalisation, 'Personalisation reset')} />
        <Btn danger label="Delete all Anna data" onPress={() => confirm('Delete everything?', 'All memories, history and settings Anna holds will be erased from this phone.', 'Delete all', async () => { await B.deleteAllAnnaData(); dataEvents.emit(); }, 'All data deleted')} />
      </View>

      <EditModal m={editing} onClose={() => setEditing(null)}
        onSave={(p) => run(async () => { await B.updateMemory(editing!.id, p); setEditing(null); })}
        onDelete={() => confirm('Delete this memory?', 'Anna will forget it.', 'Delete', async () => { await B.deleteMemory(editing!.id); setEditing(null); })} />
    </ScrollView>);
}

const LAYERS = [
  { k: 'a', t: 'A. AI model intelligence', d: 'The language model’s built-in abilities. They do not grow just because you use Anna. They only change if the model file is swapped for a better one.' },
  { k: 'b', t: 'B. Personal memory', d: 'Facts, preferences and instructions saved on your phone that Anna can look up later. You can see, edit and delete every one.' },
  { k: 'c', t: 'C. Personalisation', d: 'Anna uses your saved memories, routines, records and ratings to pick what is relevant and shape answers. Memories you rate Helpful are used more. Ones rated Incorrect are used less.' },
  { k: 'd', t: 'D. System improvement', d: 'Better behaviour that comes from updating the app code or the AI model on purpose. On-device fine-tuning is not happening, so nothing here pretends it is.' },
];

const Stat = ({ n, l }: { n: number | null; l: string }) => (
  <View style={s.stat}><Text style={s.statN}>{n == null ? '–' : n}</Text><Text style={s.tiny}>{n == null ? `${l} (not connected)` : l}</Text></View>);
const Line = ({ k, v }: { k: string; v: string }) => <View style={[s.rowBetween, { paddingVertical: 5 }]}><Text style={s.body}>{k}</Text><Text style={s.mute}>{v}</Text></View>;
const Chip = ({ label, on, onPress }: any) => <Pressable onPress={onPress} style={[s.chip, on && { backgroundColor: C.sage }]}><Text style={{ color: on ? '#fff' : C.sageDark, fontSize: 12 }}>{label}</Text></Pressable>;
const Btn = ({ label, onPress, ghost, danger }: any) => (
  <Pressable onPress={onPress} style={[s.btn, ghost && s.btnGhost, danger && { backgroundColor: '#B5594C', borderColor: '#B5594C' }]}>
    <Text style={{ color: ghost ? C.sageDark : '#fff', fontWeight: '600' }}>{label}</Text></Pressable>);

function EditModal({ m, onClose, onSave, onDelete }: { m: Memory | null; onClose: () => void; onSave: (p: any) => void; onDelete: () => void }) {
  const [text, setText] = useState(''); const [status, setStatus] = useState<MemoryStatus>('confirmed'); const [cat, setCat] = useState<CategoryKey>('about');
  useEffect(() => { if (m) { setText(m.content); setStatus(m.status); setCat(m.category); } }, [m]);
  return (
    <Modal visible={!!m} animationType="slide" transparent onRequestClose={onClose}>
      <View style={s.modalWrap}><View style={s.modal}>
        <Text style={s.h2}>Edit memory</Text>
        <TextInput style={s.input} multiline value={text} onChangeText={setText} />
        <Text style={s.tiny}>Status (assumptions only become facts when you confirm them)</Text>
        <View style={s.chips}>{(Object.keys(STATUS) as MemoryStatus[]).map(k => <Chip key={k} label={STATUS[k].label} on={status === k} onPress={() => setStatus(k)} />)}</View>
        <Text style={s.tiny}>Category</Text>
        <View style={s.chips}>{CATEGORIES.map(c => <Chip key={c.key} label={c.label} on={cat === c.key} onPress={() => setCat(c.key)} />)}</View>
        <View style={s.rowWrap}><Btn label="Save correction" onPress={() => onSave({ content: text, status, category: cat })} />
          <Btn ghost label="Cancel" onPress={onClose} /><Btn danger label="Delete" onPress={onDelete} /></View>
      </View></View>
    </Modal>);
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.cream },
  h1: { fontFamily: serif, fontSize: 32, color: C.ink, marginTop: 28 },
  h2: { fontFamily: serif, fontSize: 22, color: C.ink, marginTop: 26, marginBottom: 10 },
  sub: { color: C.mute, fontSize: 14, lineHeight: 20, marginTop: 4 },
  card: { backgroundColor: C.card, borderRadius: 16, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: C.line },
  cardTitle: { fontSize: 15, fontWeight: '600', color: C.ink }, body: { fontSize: 14, color: C.ink, lineHeight: 20 },
  label: { fontSize: 14, color: C.ink, fontWeight: '500' }, mute: { fontSize: 13, color: C.mute }, tiny: { fontSize: 12, color: C.mute, marginTop: 3 },
  row: { flexDirection: 'row', alignItems: 'center' }, rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  rowWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 }, dot: { width: 10, height: 10, borderRadius: 5, marginRight: 8 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 10 },
  stat: { width: '48%', backgroundColor: C.sageSoft, borderRadius: 14, padding: 12 }, statN: { fontFamily: serif, fontSize: 28, color: C.sageDark },
  track: { height: 8, borderRadius: 4, backgroundColor: C.blueSoft, marginTop: 6, overflow: 'hidden' }, fill: { height: 8, backgroundColor: C.sage, borderRadius: 4 },
  input: { borderWidth: 1, borderColor: C.line, borderRadius: 12, padding: 12, minHeight: 48, color: C.ink, fontSize: 15, marginBottom: 10, backgroundColor: C.cream },
  btn: { backgroundColor: C.sage, borderRadius: 12, paddingVertical: 11, paddingHorizontal: 14, alignItems: 'center', borderWidth: 1, borderColor: C.sage, marginTop: 6 },
  btnGhost: { backgroundColor: 'transparent', borderColor: C.sage },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginVertical: 6 }, chip: { backgroundColor: C.sageSoft, borderRadius: 14, paddingHorizontal: 10, paddingVertical: 6 },
  mem: { borderTopWidth: 1, borderTopColor: C.line, paddingTop: 10, marginTop: 10 }, badge: { borderRadius: 10, paddingHorizontal: 8, paddingVertical: 3 },
  tl: { flexDirection: 'row', gap: 10, marginBottom: 12 }, tlDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: C.blue, marginTop: 6 },
  modalWrap: { flex: 1, backgroundColor: 'rgba(47,58,51,0.35)', justifyContent: 'flex-end' },
  modal: { backgroundColor: C.cream, borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 18, paddingBottom: 36 },
});
