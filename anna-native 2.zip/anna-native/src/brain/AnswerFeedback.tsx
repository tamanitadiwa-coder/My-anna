// Drop under each Anna answer. memoryIds = the ids returned by retrieveRelevant() for that answer.
import React, { useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { addMemory, buildPromptContext, recordFeedback, Rating } from './brainService';

const OPTS: [Rating, string][] = [['helpful', 'Helpful'], ['not_helpful', 'Not helpful'], ['incorrect', 'Incorrect'], ['remember', 'Remember this'], ['dont_remember', 'Don’t remember this']];

export default function AnswerFeedback({ messageId, memoryIds, answerText }: { messageId: string; memoryIds: string[]; answerText: string }) {
  const [sent, setSent] = useState<Rating | null>(null);
  const send = async (rating: Rating) => {
    let proposal: Awaited<ReturnType<typeof recordFeedback>> = null;
    try { proposal = await recordFeedback({ rating, messageId, memoryIds, answerText }); }
    catch (e: any) { Alert.alert('Could not save your feedback', e?.message ?? String(e)); return; }
    setSent(rating);
    const save = (status: 'confirmed' | 'temporary') => addMemory({ ...proposal!, status, source: 'feedback' })
      .catch((e: any) => Alert.alert('Could not save the memory', e?.message ?? String(e)));
    if (proposal) Alert.alert('Save as a permanent memory?', `“${proposal.content}”`, [
      { text: 'No' },
      { text: 'Temporary', onPress: () => { save('temporary'); } },
      { text: 'Save', onPress: () => { save('confirmed'); } }]);
  };
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 6 }}>
      {OPTS.map(([k, l]) => (
        <Pressable key={k} disabled={!!sent} onPress={() => send(k)} style={[s.pill, sent === k && { backgroundColor: '#7E9C84' }]}>
          <Text style={{ fontSize: 12, color: sent === k ? '#fff' : '#4F6B56' }}>{l}</Text></Pressable>))}
    </View>);
}
const s = StyleSheet.create({ pill: { backgroundColor: '#E1EBDD', borderRadius: 14, paddingHorizontal: 10, paddingVertical: 5 } });
