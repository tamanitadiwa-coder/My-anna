export const C = { cream: '#F8F3E8', card: '#FFFCF5', sage: '#7E9C84', sageDark: '#4F6B56', sageSoft: '#E1EBDD',
  blue: '#7FA6C4', blueSoft: '#E1ECF4', ink: '#2F3A33', mute: '#7A8478', line: '#E7E0CE', warn: '#B9824A', danger: '#B5594C' };
