import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { getDb } from './db/database';
import { brainConfig, initBrain, setBrainDb } from './brain/brainService';
import { storageInfo } from './backup/backupFiles';
import * as engine from './ai/engine';
import ChatScreen from './screens/ChatScreen';
import BrainScreen from './brain/BrainScreen';
import DataScreen from './screens/DataScreen';
import TasksScreen from './screens/TasksScreen';
import MoneyScreen from './screens/MoneyScreen';
import BusinessScreen from './screens/BusinessScreen';
import { C } from './theme';

// Navigation: one custom bottom-tab bar (no Expo Router). To add a screen, add it here and to SCREENS below.
const TABS = [{ k: 'chat', l: 'Chat' }, { k: 'brain', l: 'Brain' }, { k: 'tasks', l: 'Tasks' }, { k: 'money', l: 'Money' }, { k: 'business', l: 'Business' }, { k: 'data', l: 'Data' }] as const;
type Tab = typeof TABS[number]['k'];
const SCREENS: Record<Tab, React.ComponentType> = { chat: ChatScreen, brain: BrainScreen, tasks: TasksScreen, money: MoneyScreen, business: BusinessScreen, data: DataScreen };

export default function App() {
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading');
  const [err, setErr] = useState('');
  const [tab, setTab] = useState<Tab>('chat');

  const start = async () => {
    setState('loading');
    try {
      const db = await getDb(); setBrainDb(db);
      brainConfig.getModelStatus = async () => engine.getStatus();
      brainConfig.getModelName = async () => engine.modelName();
      brainConfig.getStorage = storageInfo;
      await initBrain(); setState('ready');
    } catch (e: any) { setErr(e?.message ?? String(e)); setState('error'); }
  };
  useEffect(() => { start(); }, []);

  return (
    <SafeAreaProvider>
      <SafeAreaView style={s.root} edges={['top', 'bottom']}>
        <StatusBar style="dark" />
        {state === 'loading' && <View style={s.center}><ActivityIndicator color={C.sage} /></View>}
        {state === 'error' && (
          <View style={s.center}><Text style={s.h}>Anna could not open her memory</Text><Text style={s.p}>{err}</Text>
            <Text style={s.p}>Your data has not been changed or deleted.</Text>
            <Pressable style={s.btn} onPress={start}><Text style={{ color: '#fff', fontWeight: '600' }}>Try again</Text></Pressable></View>)}
        {state === 'ready' && (<>
          <View style={{ flex: 1 }}>
            {React.createElement(SCREENS[tab])}
          </View>
          <View style={s.tabs}>{TABS.map(t => (
            <Pressable key={t.k} style={s.tab} onPress={() => setTab(t.k)} accessibilityRole="tab" accessibilityState={{ selected: tab === t.k }}>
              <Text style={[s.tabT, tab === t.k && { color: C.sageDark, fontWeight: '700' }]}>{t.l}</Text>
              <View style={[s.dot, tab === t.k && { backgroundColor: C.sage }]} /></Pressable>))}</View>
        </>)}
      </SafeAreaView>
    </SafeAreaProvider>);
}
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.cream }, center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 28 },
  h: { fontSize: 20, color: C.ink, fontWeight: '600', marginBottom: 8 }, p: { color: C.mute, textAlign: 'center', lineHeight: 20, marginBottom: 8 },
  btn: { backgroundColor: C.sage, borderRadius: 12, paddingVertical: 12, paddingHorizontal: 22, marginTop: 8 },
  tabs: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: C.line, backgroundColor: C.card },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 10 }, tabT: { color: C.mute, fontSize: 12 }, dot: { width: 5, height: 5, borderRadius: 3, marginTop: 4, backgroundColor: 'transparent' },
});
