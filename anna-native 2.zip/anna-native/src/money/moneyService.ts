import type { Db } from '../db/types';
import { cleanText, InputError, uid } from '../util/validation';
import { MAX_CENTS } from '../util/money';
import { addMonths, startOfDay, startOfMonth, startOfNextMonth } from '../util/dates';

export interface Transaction { id: string; kind: 'income' | 'expense'; amount_cents: number; category: string; note: string | null; occurred_at: number; created_at: number; updated_at: number }
export interface Bill { id: string; name: string; amount_cents: number; due_at: number; repeat_monthly: 0 | 1; paid: 0 | 1; paid_at: number | null; created_at: number; updated_at: number }
export interface Budget { id: string; category: string; limit_cents: number; created_at: number; updated_at: number }

function cents(n: number) { if (!Number.isInteger(n) || n <= 0 || n > MAX_CENTS) throw new InputError('Please enter an amount greater than zero.'); return n; }

// ---- Settings (currency symbol etc.) ---------------------------------------
export async function getSetting(db: Db, key: string): Promise<string | null> {
  return (await db.getFirstAsync<{ value: string }>(`SELECT value FROM app_settings WHERE key=?`, key))?.value ?? null;
}
export async function setSetting(db: Db, key: string, value: string) { await db.runAsync(`INSERT OR REPLACE INTO app_settings VALUES(?,?)`, key, value); }
export async function getCurrency(db: Db) { return (await getSetting(db, 'currency')) ?? ''; }
export async function setCurrency(db: Db, symbol: string) { await setSetting(db, 'currency', (cleanText(symbol, 'a currency symbol', 5, false) ?? '')); }

// ---- Income & expenses -----------------------------------------------------
export async function addTransaction(db: Db, p: { kind: 'income' | 'expense'; amountCents: number; category?: string; note?: string; occurredAt?: number }) {
  if (p.kind !== 'income' && p.kind !== 'expense') throw new InputError('Choose income or expense.');
  const category = cleanText(p.category, 'a category', 60, false) ?? 'General'; const note = cleanText(p.note, 'a note', 300, false);
  const id = uid(), t = Date.now();
  await db.runAsync(`INSERT INTO transactions(id,kind,amount_cents,category,note,occurred_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)`,
    id, p.kind, cents(p.amountCents), category, note, p.occurredAt ?? t, t, t);
  return id;
}
export const deleteTransaction = (db: Db, id: string) => db.runAsync(`DELETE FROM transactions WHERE id=?`, id);
export const listTransactions = (db: Db, limit = 50) =>
  db.getAllAsync<Transaction>(`SELECT * FROM transactions ORDER BY occurred_at DESC, created_at DESC LIMIT ?`, limit);

export async function monthSummary(db: Db, now = Date.now()) {
  const from = startOfMonth(now), to = startOfNextMonth(now);
  const sum = async (kind: string) => (await db.getFirstAsync<{ s: number | null }>(
    `SELECT SUM(amount_cents) s FROM transactions WHERE kind=? AND occurred_at>=? AND occurred_at<?`, kind, from, to))!.s ?? 0;
  const income = await sum('income'), expense = await sum('expense');
  const byCategory = await db.getAllAsync<{ category: string; total: number }>(
    `SELECT category, SUM(amount_cents) total FROM transactions WHERE kind='expense' AND occurred_at>=? AND occurred_at<? GROUP BY category COLLATE NOCASE ORDER BY total DESC`, from, to);
  return { income, expense, net: income - expense, byCategory };
}

// ---- Bills -----------------------------------------------------------------
export async function addBill(db: Db, p: { name: string; amountCents: number; dueAt: number; repeatMonthly?: boolean }) {
  const name = cleanText(p.name, 'a bill name', 100)!; const id = uid(), t = Date.now();
  if (!Number.isFinite(p.dueAt)) throw new InputError('Please choose a due date.');
  await db.runAsync(`INSERT INTO bills(id,name,amount_cents,due_at,repeat_monthly,paid,paid_at,created_at,updated_at) VALUES(?,?,?,?,?,0,NULL,?,?)`,
    id, name, cents(p.amountCents), p.dueAt, p.repeatMonthly ? 1 : 0, t, t);
  return id;
}
export const deleteBill = (db: Db, id: string) => db.runAsync(`DELETE FROM bills WHERE id=?`, id);
export const listBills = (db: Db, includePaid = false) =>
  db.getAllAsync<Bill>(`SELECT * FROM bills ${includePaid ? '' : 'WHERE paid=0'} ORDER BY paid, due_at`);

/**
 * Marks a bill paid. Optionally records the matching expense and, for monthly bills, creates next month's bill.
 * All in one transaction. Paying the same bill twice is refused, so an expense can never be double-counted.
 */
export async function markBillPaid(db: Db, id: string, opts: { recordExpense?: boolean; now?: number } = {}) {
  const now = opts.now ?? Date.now();
  await db.withTransactionAsync(async () => {
    const b = await db.getFirstAsync<Bill>(`SELECT * FROM bills WHERE id=?`, id);
    if (!b) throw new InputError('That bill no longer exists.');
    if (b.paid) throw new InputError('That bill is already marked as paid.');
    await db.runAsync(`UPDATE bills SET paid=1, paid_at=?, updated_at=? WHERE id=?`, now, now, id);
    if (opts.recordExpense) await addTransaction(db, { kind: 'expense', amountCents: b.amount_cents, category: 'Bills', note: b.name, occurredAt: now });
    if (b.repeat_monthly) await addBill(db, { name: b.name, amountCents: b.amount_cents, dueAt: addMonths(b.due_at, 1), repeatMonthly: true });
  });
}

export async function billSummary(db: Db, now = Date.now()) {
  const today = startOfDay(now), soon = today + 7 * 86400000;
  const row = await db.getFirstAsync<{ n: number; total: number | null; overdue: number; soon: number }>(
    `SELECT COUNT(*) n, SUM(amount_cents) total,
       SUM(CASE WHEN due_at < ? THEN 1 ELSE 0 END) overdue, SUM(CASE WHEN due_at >= ? AND due_at < ? THEN 1 ELSE 0 END) soon
     FROM bills WHERE paid=0`, today, today, soon);
  return { unpaid: row?.n ?? 0, unpaidCents: row?.total ?? 0, overdue: row?.overdue ?? 0, dueWithin7Days: row?.soon ?? 0 };
}

// ---- Budgets (monthly limit per category) ----------------------------------
export async function setBudget(db: Db, category: string, limitCents: number) {
  const cat = cleanText(category, 'a category', 60)!; const t = Date.now();
  const ex = await db.getFirstAsync<{ id: string }>(`SELECT id FROM budgets WHERE category=?`, cat);
  if (ex) { await db.runAsync(`UPDATE budgets SET limit_cents=?, updated_at=? WHERE id=?`, cents(limitCents), t, ex.id); return ex.id; }
  const id = uid(); await db.runAsync(`INSERT INTO budgets(id,category,limit_cents,created_at,updated_at) VALUES(?,?,?,?,?)`, id, cat, cents(limitCents), t, t); return id;
}
export const deleteBudget = (db: Db, id: string) => db.runAsync(`DELETE FROM budgets WHERE id=?`, id);

export async function budgetStatus(db: Db, now = Date.now()) {
  const from = startOfMonth(now), to = startOfNextMonth(now);
  const rows = await db.getAllAsync<Budget & { spent: number }>(
    `SELECT b.*, COALESCE((SELECT SUM(amount_cents) FROM transactions t WHERE t.kind='expense' AND t.category=b.category COLLATE NOCASE
       AND t.occurred_at>=? AND t.occurred_at<?),0) AS spent FROM budgets b ORDER BY b.category`, from, to);
  return rows.map(r => ({ ...r, remaining: r.limit_cents - r.spent, used: r.spent / r.limit_cents, over: r.spent > r.limit_cents }));
}
