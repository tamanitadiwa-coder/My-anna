import type { Db } from "../db/types";
export interface ChatMessage { id: string; conversation_id: string; role: "user" | "assistant" | "system"; content: string; memory_ids: string | null; created_at: number }
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
export const MAX_MESSAGE_CHARS = 4000;

export async function createConversation(db: Db, firstText: string) {
  const id = uid(), t = Date.now(); const title = firstText.trim().replace(/\s+/g, " ").slice(0, 40) || "New chat";
  await db.runAsync("INSERT INTO conversations VALUES(?,?,?,?)", id, title, t, t);
  return id;
}
export async function latestConversationId(db: Db) {
  return (await db.getFirstAsync<{ id: string }>("SELECT id FROM conversations ORDER BY updated_at DESC LIMIT 1"))?.id ?? null;
}
export async function addMessage(db: Db, conversationId: string, role: ChatMessage["role"], content: string, memoryIds: string[] = []) {
  const id = uid(), t = Date.now();
  await db.withTransactionAsync(async () => {
    await db.runAsync("INSERT INTO messages VALUES(?,?,?,?,?,?)", id, conversationId, role, content, memoryIds.length ? JSON.stringify(memoryIds) : null, t);
    await db.runAsync("UPDATE conversations SET updated_at=? WHERE id=?", t, conversationId);
  });
  return id;
}
export const listMessages = (db: Db, conversationId: string) =>
  db.getAllAsync<ChatMessage>("SELECT * FROM messages WHERE conversation_id=? ORDER BY created_at, rowid", conversationId);
export const parseIds = (s: string | null): string[] => { try { const v = JSON.parse(s ?? "[]"); return Array.isArray(v) ? v : []; } catch { return []; } };
