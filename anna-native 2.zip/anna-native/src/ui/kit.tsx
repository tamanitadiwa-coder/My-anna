// Small shared building blocks for the Tasks, Money and Business screens (same look as Brain/Chat/Data).
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { C } from '../theme';
import { dataEvents } from '../util/events';
import { addDays, formatDate } from '../util/dates';

export const serif = Platform.select({ ios: 'Georgia', default: 'serif' });

export const Card = ({ children, style }: { children: React.ReactNode; style?: any }) => <View style={[k.card, style]}>{children}</View>;
export const H1 = ({ children }: { children: React.ReactNode }) => <Text style={k.h1}>{children}</Text>;
export const H2 = ({ children }: { children: React.ReactNode }) => <Text style={k.h2}>{children}</Text>;
export const Mute = ({ children, style }: { children: React.ReactNode; style?: any }) => <Text style={[k.mute, style]}>{children}</Text>;
export const Body = ({ children, style }: { children: React.ReactNode; style?: any }) => <Text style={[k.body, style]}>{children}</Text>;

export function Btn({ label, onPress, ghost, danger, small }: { label: string; onPress: () => void; ghost?: boolean; danger?: boolean; small?: boolean }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button"
      style={[k.btn, small && { paddingVertical: 7, paddingHorizontal: 10 }, ghost && k.btnGhost, danger && { backgroundColor: C.danger, borderColor: C.danger }]}>
      <Text style={{ color: ghost ? C.sageDark : '#fff', fontWeight: '600', fontSize: small ? 13 : 15 }}>{label}</Text>
    </Pressable>);
}
export const Chip = ({ label, on, onPress }: { label: string; on?: boolean; onPress: () => void }) => (
  <Pressable onPress={onPress} style={[k.chip, on && { backgroundColor: C.sage }]}><Text style={{ color: on ? '#fff' : C.sageDark, fontSize: 13 }}>{label}</Text></Pressable>);

/** Segmented choice, e.g. Income | Expense. */
export function Seg<T extends string>({ value, options, onChange }: { value: T; options: { key: T; label: string }[]; onChange: (v: T) => void }) {
  return (
    <View style={k.seg}>{options.map(o => (
      <Pressable key={o.key} onPress={() => onChange(o.key)} accessibilityRole="tab" accessibilityState={{ selected: value === o.key }}
        style={[k.segItem, value === o.key && { backgroundColor: C.sage }]}>
        <Text style={{ color: value === o.key ? '#fff' : C.sageDark, fontWeight: '600', fontSize: 13 }}>{o.label}</Text></Pressable>))}</View>);
}

export function Field({ label, value, onChangeText, placeholder, keyboardType, multiline, maxLength }:
  { label?: string; value: string; onChangeText: (s: string) => void; placeholder?: string; keyboardType?: any; multiline?: boolean; maxLength?: number }) {
  return (
    <View style={{ marginBottom: 8 }}>
      {!!label && <Text style={k.tiny}>{label}</Text>}
      <TextInput style={[k.input, multiline && { minHeight: 70, textAlignVertical: 'top' }]} value={value} onChangeText={onChangeText} placeholder={placeholder}
        placeholderTextColor={C.mute} keyboardType={keyboardType} multiline={multiline} maxLength={maxLength} autoCorrect={false} />
    </View>);
}

/** Date typed as YYYY-MM-DD, with quick buttons. */
export function DateField({ label, value, onChangeText }: { label: string; value: string; onChangeText: (s: string) => void }) {
  const now = Date.now();
  return (
    <View style={{ marginBottom: 8 }}>
      <Field label={label} value={value} onChangeText={onChangeText} placeholder="YYYY-MM-DD" keyboardType="numbers-and-punctuation" maxLength={10} />
      <View style={k.chips}>
        <Chip label="Today" onPress={() => onChangeText(formatDate(now))} /><Chip label="Tomorrow" onPress={() => onChangeText(formatDate(addDays(now, 1)))} />
        <Chip label="In 7 days" onPress={() => onChangeText(formatDate(addDays(now, 7)))} /><Chip label="Clear" onPress={() => onChangeText('')} />
      </View>
    </View>);
}

export const Bar = ({ value, over }: { value: number; over?: boolean }) => (
  <View style={k.track}><View style={[k.fill, { width: `${Math.min(Math.max(value, 0), 1) * 100}%`, backgroundColor: over ? C.danger : C.sage }]} /></View>);

export const Stat = ({ label, value, tone }: { label: string; value: string; tone?: 'good' | 'bad' }) => (
  <View style={k.stat}><Text style={[k.statN, tone === 'bad' && { color: C.danger }]}>{value}</Text><Text style={k.tiny}>{label}</Text></View>);

/**
 * One place for the "load data, reload after changes or restores, run actions once, show errors" pattern.
 * `load` must be stable (wrap it in useCallback).
 */
export function useScreenData(load: () => Promise<void>) {
  const [error, setError] = useState<string | null>(null); const [busy, setBusy] = useState(false); const lock = useRef(false);
  const reload = useCallback(async () => { try { await load(); setError(null); } catch (e: any) { setError(e?.message ?? String(e)); } }, [load]);
  useEffect(() => { reload(); }, [reload]);
  useEffect(() => dataEvents.subscribe(() => { reload(); }), [reload]);
  /** Runs an action once at a time (double taps are ignored), shows a plain message if it fails, then reloads. */
  const run = useCallback(async (fn: () => Promise<any>): Promise<boolean> => {
    if (lock.current) return false; lock.current = true; setBusy(true); let ok = true;
    try { await fn(); } catch (e: any) { ok = false; Alert.alert('Could not do that', e?.message ?? String(e)); }
    lock.current = false; setBusy(false); await reload(); return ok;
  }, [reload]);
  return { error, busy, run, reload };
}
export const confirmDelete = (title: string, msg: string, onYes: () => void) =>
  Alert.alert(title, msg, [{ text: 'Cancel', style: 'cancel' }, { text: 'Delete', style: 'destructive', onPress: onYes }]);

export const k = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.cream },
  h1: { fontFamily: serif, fontSize: 30, color: C.ink, marginTop: 20 }, h2: { fontFamily: serif, fontSize: 20, color: C.ink, marginTop: 22, marginBottom: 8 },
  card: { backgroundColor: C.card, borderRadius: 16, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: C.line },
  body: { fontSize: 15, color: C.ink, lineHeight: 21 }, mute: { fontSize: 13, color: C.mute, lineHeight: 18 }, tiny: { fontSize: 12, color: C.mute, marginTop: 3, marginBottom: 3 },
  input: { borderWidth: 1, borderColor: C.line, borderRadius: 12, padding: 11, minHeight: 44, color: C.ink, fontSize: 15, backgroundColor: C.cream },
  btn: { backgroundColor: C.sage, borderRadius: 12, paddingVertical: 11, paddingHorizontal: 14, alignItems: 'center', borderWidth: 1, borderColor: C.sage, marginTop: 6 },
  btnGhost: { backgroundColor: 'transparent' },
  chip: { backgroundColor: C.sageSoft, borderRadius: 14, paddingHorizontal: 11, paddingVertical: 6 }, chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginVertical: 4 },
  seg: { flexDirection: 'row', backgroundColor: C.sageSoft, borderRadius: 12, padding: 3, marginVertical: 8 },
  segItem: { flex: 1, alignItems: 'center', paddingVertical: 8, borderRadius: 10 },
  row: { flexDirection: 'row', alignItems: 'center' }, between: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  track: { height: 8, borderRadius: 4, backgroundColor: C.blueSoft, marginTop: 6, overflow: 'hidden' }, fill: { height: 8, borderRadius: 4 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 10 },
  stat: { width: '48%', backgroundColor: C.sageSoft, borderRadius: 14, padding: 12 }, statN: { fontFamily: serif, fontSize: 24, color: C.sageDark },
  item: { borderTopWidth: 1, borderTopColor: C.line, paddingTop: 10, marginTop: 10 },
  err: { color: C.danger, marginTop: 10 },
});
