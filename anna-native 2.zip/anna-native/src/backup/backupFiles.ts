// File side of backups (phone only). The logic lives in backupCore.ts, which is unit-tested.
import { Directory, File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as DocumentPicker from 'expo-document-picker';
import * as SQLite from 'expo-sqlite';
import { getDb, DB_NAME } from '../db/database';
import { createBackup, restoreWithSafetyNet, validateBackup, BackupError, BackupPayload, Scope } from './backupCore';
import { markBackupDone } from '../brain/brainService';

const backupsDir = () => { const d = new Directory(Paths.document, 'backups'); if (!d.exists) d.create({ intermediates: true } as any); return d; };

/** Writes to a temporary file first, verifies it by reading it back, then renames. An interrupted backup never replaces a good one. */
export async function writeBackupFile(payload: BackupPayload, prefix: string): Promise<File> {
  const text = JSON.stringify(payload);
  const need = text.length * 2 + 20_000_000; // file + safety margin
  if (Paths.availableDiskSpace < need) throw new Error('Not enough free storage on this iPhone to create the backup. Free up some space and try again.');
  const dir = backupsDir(); const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const tmp = new File(dir, `${prefix}-${stamp}.tmp`); const final = new File(dir, `${prefix}-${stamp}.json`);
  try {
    tmp.create({ overwrite: true } as any); tmp.write(text);
    validateBackup(JSON.parse(await tmp.text())); // read-back verification
    tmp.move(final);
  } catch (e) { try { if (tmp.exists) tmp.delete(); } catch {} throw e; }
  return final;
}
async function share(f: File) { if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(f.uri, { mimeType: 'application/json', dialogTitle: 'Save Anna backup' }); }

export async function createAndShareBackup(scope: Scope, kind: 'backup' | 'export' = 'backup') {
  const file = await writeBackupFile(await createBackup(await getDb(), scope), scope === 'full' ? 'anna-full' : 'anna-brain');
  await markBackupDone(kind); await share(file); return file;
}

export async function pickBackup(): Promise<any | null> {
  const r = await DocumentPicker.getDocumentAsync({ type: ['application/json', 'text/plain', '*/*'], copyToCacheDirectory: true });
  if (r.canceled) return null;
  let parsed: any;
  try { parsed = JSON.parse(await new File(r.assets[0].uri).text()); } catch { throw new BackupError('That file could not be read as an Anna backup.'); }
  validateBackup(parsed); return parsed;
}
export async function restoreFromPayload(payload: any, mode: 'merge' | 'replace') {
  return restoreWithSafetyNet(await getDb(), payload, mode, async snap => { await writeBackupFile(snap, 'anna-before-restore'); });
}

export async function storageInfo() {
  let dbBytes: number | null = null;
  try { const f = new File(SQLite.defaultDatabaseDirectory, DB_NAME); dbBytes = f.exists ? f.size : null; } catch {}
  let freeBytes: number | null = null; try { freeBytes = Paths.availableDiskSpace; } catch {}
  return { dbBytes, freeBytes };
}
