// Pure backup/restore logic (no file access) so it can be tested without a phone.
import type { Db } from '../db/types';
import { LATEST_VERSION } from '../db/migrations';
import { sha256 } from '../util/sha256';

export type Scope = 'full' | 'brain';
export const BACKUP_FORMAT = 'anna-backup';
export const BACKUP_VERSION = 1;
// Every table that can be backed up. Parents before children (insert order); delete order is the reverse.
// `since` = the schema version that introduced the table, so older backup files stay restorable.
// A 'brain' backup only ever contains the Brain tables: restoring one can never touch chats, tasks or money.
const TABLE_DEFS: { name: string; since: number; scopes: Scope[] }[] = [
  { name: 'conversations', since: 1, scopes: ['full'] },
  { name: 'messages', since: 1, scopes: ['full'] },
  { name: 'brain_memories', since: 1, scopes: ['full', 'brain'] },
  { name: 'brain_feedback', since: 1, scopes: ['full', 'brain'] },
  { name: 'brain_events', since: 1, scopes: ['full', 'brain'] },
  { name: 'brain_meta', since: 1, scopes: ['full', 'brain'] },
  { name: 'tasks', since: 2, scopes: ['full'] },
  { name: 'transactions', since: 2, scopes: ['full'] },
  { name: 'bills', since: 2, scopes: ['full'] },
  { name: 'budgets', since: 2, scopes: ['full'] },
  { name: 'business_records', since: 2, scopes: ['full'] },
  { name: 'app_settings', since: 2, scopes: ['full'] },
];
const META_KEYS = ['started']; // transient meta (model status, last backup) is never exported
/** Tables a backup of this scope and schema version must contain (and may only contain). */
const tablesFor = (s: Scope, schemaVersion: number = LATEST_VERSION): readonly string[] =>
  TABLE_DEFS.filter(t => t.scopes.includes(s) && t.since <= schemaVersion).map(t => t.name);

export class BackupError extends Error {}
export interface BackupPayload {
  format: typeof BACKUP_FORMAT; backupVersion: number; schemaVersion: number; scope: Scope;
  createdAt: number; tables: Record<string, any[]>; checksum: string;
}
const checksumOf = (schemaVersion: number, scope: Scope, tables: Record<string, any[]>) =>
  sha256(JSON.stringify({ schemaVersion, scope, tables }));

export async function createBackup(db: Db, scope: Scope = 'full'): Promise<BackupPayload> {
  const tables: Record<string, any[]> = {};
  // One transaction = one consistent snapshot, even if the app writes while we read.
  await db.withTransactionAsync(async () => {
    for (const t of tablesFor(scope)) {
      tables[t] = t === 'brain_meta'
        ? await db.getAllAsync(`SELECT * FROM brain_meta WHERE key IN (${META_KEYS.map(() => '?').join(',')})`, ...META_KEYS)
        : await db.getAllAsync(`SELECT * FROM ${t}`);
    }
  });
  return { format: BACKUP_FORMAT, backupVersion: BACKUP_VERSION, schemaVersion: LATEST_VERSION, scope,
    createdAt: Date.now(), tables, checksum: checksumOf(LATEST_VERSION, scope, tables) };
}

/** Throws BackupError with a plain-English reason if the file can't be trusted. */
export function validateBackup(p: any): { scope: Scope; counts: Record<string, number> } {
  if (!p || typeof p !== 'object') throw new BackupError('This file is not an Anna backup.');
  if (p.format !== BACKUP_FORMAT) throw new BackupError('This file is not an Anna backup.');
  if (typeof p.backupVersion !== 'number' || p.backupVersion > BACKUP_VERSION)
    throw new BackupError('This backup was made by a newer version of Anna. Update the app first.');
  if (typeof p.schemaVersion !== 'number' || p.schemaVersion > LATEST_VERSION)
    throw new BackupError('This backup was made by a newer version of Anna. Update the app first.');
  if (p.scope !== 'full' && p.scope !== 'brain') throw new BackupError('Backup type is unknown.');
  if (!p.tables || typeof p.tables !== 'object') throw new BackupError('Backup contains no data tables.');
  const counts: Record<string, number> = {};
  const expected = tablesFor(p.scope, p.schemaVersion);
  for (const t of expected) {
    if (!Array.isArray(p.tables[t])) throw new BackupError(`Backup is incomplete (missing “${t}”).`);
    counts[t] = p.tables[t].length;
  }
  for (const t of Object.keys(p.tables)) if (!expected.includes(t)) throw new BackupError(`Backup contains an unexpected table “${t}”.`);
  if (checksumOf(p.schemaVersion, p.scope, p.tables) !== p.checksum)
    throw new BackupError('Backup is damaged (checksum does not match). It may have been edited or only partly copied.');
  return { scope: p.scope, counts };
}

type Col = { name: string; notnull: number; dflt_value: any; pk: number };
function checkRow(table: string, cols: Col[], r: any) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) throw new BackupError(`A row in “${table}” is not valid.`);
  const names = cols.map(c => c.name);
  for (const k of Object.keys(r)) if (!names.includes(k)) throw new BackupError(`Unknown field “${k}” in “${table}”.`);
  for (const c of cols) if (c.notnull && c.dflt_value == null && (r[c.name] === undefined || r[c.name] === null))
    throw new BackupError(`A row in “${table}” is missing “${c.name}”.`);
}

/** Replace mode: the table was just emptied, so every row is simply inserted. */
async function insertRows(db: Db, table: string, rows: any[]) {
  if (!rows.length) return;
  const cols = await db.getAllAsync<Col>(`PRAGMA table_info(${table})`);
  for (const r of rows) {
    checkRow(table, cols, r);
    const keys = Object.keys(r);
    await db.runAsync(`INSERT OR REPLACE INTO ${table} (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`, ...keys.map(k => r[k]));
  }
}

/**
 * Merge mode: add what is missing and never delete anything.
 * A row that already exists is changed in place (never delete+insert, which would cascade-delete child rows such as
 * chat messages) and only if the backup's copy is strictly newer (updated_at). Otherwise the local copy wins.
 */
async function mergeRows(db: Db, table: string, rows: any[]) {
  if (!rows.length) return;
  const cols = await db.getAllAsync<Col>(`PRAGMA table_info(${table})`);
  const pk = cols.filter(c => c.pk > 0).sort((a, b) => a.pk - b.pk).map(c => c.name);
  const hasUpdated = cols.some(c => c.name === 'updated_at');
  for (const r of rows) {
    checkRow(table, cols, r);
    for (const k of pk) if (r[k] === undefined || r[k] === null) throw new BackupError(`A row in “${table}” is missing “${k}”.`);
    const where = pk.map(k => `${k}=?`).join(' AND '); const keyVals = pk.map(k => r[k]);
    const existing = await db.getFirstAsync<{ u: number | null }>(`SELECT ${hasUpdated ? 'updated_at' : 'NULL'} AS u FROM ${table} WHERE ${where}`, ...keyVals);
    if (!existing) {
      const keys = Object.keys(r);
      await db.runAsync(`INSERT INTO ${table} (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`, ...keys.map(k => r[k]));
    } else if (hasUpdated && typeof r.updated_at === 'number' && typeof existing.u === 'number' && r.updated_at > existing.u) {
      const sets = Object.keys(r).filter(k => !pk.includes(k));
      if (sets.length) await db.runAsync(`UPDATE ${table} SET ${sets.map(k => `${k}=?`).join(',')} WHERE ${where}`, ...sets.map(k => r[k]), ...keyVals);
    } // else: the local copy is kept
  }
}

/**
 * All-or-nothing. If ANY step fails the transaction rolls back and the existing data is untouched.
 * Only tables that the backup file actually covers are ever touched (an old backup never wipes newer modules).
 */
export async function restoreBackup(db: Db, payload: any, mode: 'merge' | 'replace') {
  const { scope, counts } = validateBackup(payload);
  const tables = tablesFor(scope, payload.schemaVersion);
  await db.withTransactionAsync(async () => {
    if (mode === 'replace') {
      for (const t of [...tables].reverse()) {
        if (t === 'brain_meta') await db.runAsync(`DELETE FROM brain_meta WHERE key IN (${META_KEYS.map(() => '?').join(',')})`, ...META_KEYS);
        else await db.runAsync(`DELETE FROM ${t}`);
      }
    }
    for (const t of tables) await (mode === 'merge' ? mergeRows : insertRows)(db, t, payload.tables[t]);
  });
  return counts;
}

/**
 * Turns a full backup into a Brain-only backup (memories, feedback, history). Restoring the result cannot touch
 * chats, tasks, money or business data. The new file gets its own checksum.
 */
export function extractBrainOnly(payload: any): BackupPayload {
  validateBackup(payload);
  if (payload.scope === 'brain') return payload as BackupPayload;
  const tables: Record<string, any[]> = {};
  for (const t of tablesFor('brain', payload.schemaVersion)) tables[t] = payload.tables[t];
  return { format: BACKUP_FORMAT, backupVersion: payload.backupVersion, schemaVersion: payload.schemaVersion, scope: 'brain',
    createdAt: payload.createdAt, tables, checksum: checksumOf(payload.schemaVersion, 'brain', tables) };
}

/**
 * Safe restore: first asks the caller to save a snapshot of what exists now, then restores.
 * If the snapshot cannot be saved, nothing is changed.
 */
export async function restoreWithSafetyNet(db: Db, payload: any, mode: 'merge' | 'replace',
  saveSnapshot: (snapshot: BackupPayload) => Promise<void>) {
  validateBackup(payload); // reject bad files before touching anything
  await saveSnapshot(await createBackup(db, 'full'));
  return restoreBackup(db, payload, mode);
}

export async function wipeAll(db: Db) {
  await db.withTransactionAsync(async () => {
    for (const t of [...tablesFor('full')].reverse()) await db.runAsync(`DELETE FROM ${t}`);
  });
}
