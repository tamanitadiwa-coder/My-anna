/** Thrown for bad user input. The message is written for the person using the app. */
export class InputError extends Error {}
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

export function cleanText(s: string | null | undefined, field: string, max: number, required = true): string | null {
  const t = (s ?? '').trim();
  if (!t) { if (required) throw new InputError(`Please enter ${field}.`); return null; }
  if (t.length > max) throw new InputError(`${field[0].toUpperCase() + field.slice(1)} can be up to ${max} characters.`);
  return t;
}
