type Fn = () => void;
const subs = new Set<Fn>();
/** Tells screens that data changed under them (after a restore, a wipe, etc.). */
export const dataEvents = { emit: () => subs.forEach(f => f()), subscribe: (f: Fn) => { subs.add(f); return () => { subs.delete(f); }; } };
