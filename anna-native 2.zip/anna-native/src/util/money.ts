// Money is always stored as whole cents (integers). These helpers convert to and from what people type and read.
export const MAX_CENTS = 100_000_000_000; // 1 billion units: a sanity limit, not a real-world limit

/** "1,250.50" → 125050, "1250" → 125000, "12,5" → 1250, "R 1 250" → 125000. Returns null if it is not a positive amount. */
export function parseAmountToCents(input: string): number | null {
  // Optional short currency prefix ("R", "$", "USD"), then digits with spaces, commas or dots. Anything else (minus signs, "1e9", words) is rejected.
  if (!/^\s*[^\d\-.,\s]{0,3}\s*\d[\d\s.,]*$/.test(input ?? '')) return null;
  let t = input.replace(/[^\d.,]/g, '');
  const lastDot = t.lastIndexOf('.'), lastComma = t.lastIndexOf(',');
  if (lastDot >= 0 && lastComma >= 0) {
    const dec = Math.max(lastDot, lastComma), thousands = dec === lastDot ? ',' : '.';
    t = t.split(thousands).join('').replace(dec === lastDot ? '.' : ',', '.');
  } else if (lastComma >= 0) {
    // one comma followed by 1–2 digits is a decimal comma ("12,5"); otherwise commas are thousands separators
    t = /^\d*,\d{1,2}$/.test(t) ? t.replace(',', '.') : t.split(',').join('');
  } else if ((t.match(/\./g) ?? []).length > 1) t = t.split('.').join('');
  if (!/^\d*\.?\d*$/.test(t)) return null;
  const [whole, frac = ''] = t.split('.');
  if (frac.length > 2) return null;
  const cents = Number(whole || '0') * 100 + Number(frac.padEnd(2, '0') || '0');
  return Number.isFinite(cents) && cents > 0 && cents <= MAX_CENTS ? cents : null;
}

/** 125050 → "1,250.50" (with an optional currency symbol in front). */
export function formatCents(cents: number, symbol = ''): string {
  const neg = cents < 0; const abs = Math.abs(Math.round(cents));
  const whole = String(Math.floor(abs / 100)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `${neg ? '-' : ''}${symbol}${whole}.${String(abs % 100).padStart(2, '0')}`;
}
