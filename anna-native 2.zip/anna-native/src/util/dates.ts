// Calendar helpers. "Day" always means the local calendar day on the phone.
export const startOfDay = (t: number) => { const d = new Date(t); return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); };
export const startOfMonth = (t: number) => { const d = new Date(t); return new Date(d.getFullYear(), d.getMonth(), 1).getTime(); };
export const startOfNextMonth = (t: number) => { const d = new Date(t); return new Date(d.getFullYear(), d.getMonth() + 1, 1).getTime(); };
export const addDays = (t: number, n: number) => { const d = new Date(startOfDay(t)); d.setDate(d.getDate() + n); return d.getTime(); };

/** Same day next month; if that day does not exist (31 Jan → 28/29 Feb) the last day of that month is used. */
export function addMonths(t: number, n = 1): number {
  const d = new Date(t); const day = d.getDate();
  const target = new Date(d.getFullYear(), d.getMonth() + n, 1);
  const last = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
  return new Date(target.getFullYear(), target.getMonth(), Math.min(day, last)).getTime();
}

/** "2026-12-31" → local midnight of that day. Returns null for anything that is not a real calendar date. */
export function parseDateInput(s: string): number | null {
  const m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec((s ?? '').trim()); if (!m) return null;
  const y = +m[1], mo = +m[2], d = +m[3]; const t = new Date(y, mo - 1, d);
  return t.getFullYear() === y && t.getMonth() === mo - 1 && t.getDate() === d ? t.getTime() : null;
}
export const formatDate = (t: number) => { const d = new Date(t); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
