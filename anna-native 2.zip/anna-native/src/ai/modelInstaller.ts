// Local AI model installation logic. Pure (no Expo imports) so it is unit-tested with a fake file store.
// The real phone-side file store lives in modelFiles.ts.
//
// Safety rules:
//  - a new model is written to "<name>.part" and only becomes the active model after it is checked;
//  - the previous model is kept until the new one is verified, and is put back if anything fails after that point;
//  - Anna keeps ONE model at a time (installing a new one replaces the old one) to protect phone storage.

export class ModelInstallError extends Error {}
export const MB = 1024 * 1024, GB = 1024 * MB;
export const MIN_MODEL_BYTES = 50 * MB;          // anything smaller is certainly not a usable model
export const SPACE_MARGIN_BYTES = 300 * MB;      // headroom so the phone is never filled to the brim
export const UNKNOWN_SIZE_MIN_FREE = 2.5 * GB;   // when the download size cannot be learned in advance
export const BIG_MODEL_WARNING_BYTES = 3.5 * GB; // large models can run out of memory on phones with 6 GB RAM

export interface ModelStore {
  freeBytes(): number | null;
  listFiles(): string[];                              // every file name in the models folder
  sizeOf(name: string): number | null;                // null if the file does not exist
  remove(name: string): void;                         // no error if missing
  rename(from: string, to: string): void;             // fails if "to" exists
  readMagic(name: string): string | null;             // first 4 characters, or null if it cannot be read
  contentLength(url: string): Promise<number | null>; // size announced by the server, or null
  download(url: string, intoName: string, onBytes: (n: number) => void): Promise<void>;
  importPicked(srcUri: string, intoName: string): Promise<void>;
}
export interface InstallOptions {
  expectedBytes?: number | null;
  onProgress?: (doneBytes: number, totalBytes: number | null) => void;
  /** Called right before the active model file is swapped (unload the running model here). */
  beforeSwap?: () => Promise<void>;
}

/** Only https links to a .gguf file, no embedded passwords. Returns the link and a safe file name. */
export function parseModelUrl(input: string): { url: string; fileName: string } {
  const url = (input ?? '').trim();
  const m = /^https:\/\/([^\/?#@\s]+)(\/[^?#\s]*)?(\?[^#\s]*)?(#\S*)?$/i.exec(url);
  if (!m) throw new ModelInstallError('Please paste a full https:// link to a .gguf model file.');
  const last = (m[2] ?? '').split('/').filter(Boolean).pop() ?? '';
  let decoded = last; try { decoded = decodeURIComponent(last); } catch {}
  return { url, fileName: safeModelFileName(decoded) };
}

export function safeModelFileName(name: string): string {
  const n = (name ?? '').trim();
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,118}\.gguf$/i.test(n) || n.includes('..'))
    throw new ModelInstallError('The model file name must end in .gguf and use only letters, numbers, dots, dashes and underscores.');
  return n;
}

export function requiredFreeBytes(expected: number | null | undefined): number {
  return expected && expected > 0 ? Math.ceil(expected * 1.05) + SPACE_MARGIN_BYTES : UNKNOWN_SIZE_MIN_FREE;
}
export function checkSpace(free: number | null, expected: number | null | undefined) {
  if (free == null) return; // cannot be measured: let the phone report it if the disk really is full
  const need = requiredFreeBytes(expected);
  if (free < need) throw new ModelInstallError(
    `Not enough free storage. This needs about ${(need / GB).toFixed(1)} GB free; this iPhone has ${(free / GB).toFixed(1)} GB. Free up some space and try again.`);
}
export const bigModelWarning = (bytes: number | null | undefined) =>
  bytes && bytes > BIG_MODEL_WARNING_BYTES ? 'This is a large model. It may be slow or may close the app on an iPhone with 6 GB of memory. A smaller model (under about 3 GB) is safer.' : null;

const part = (n: string) => `${n}.part`, old = (n: string) => `${n}.old`;

/** Run at app/screen start: removes half-finished downloads and repairs an interrupted swap. */
export function cleanupLeftovers(store: ModelStore) {
  const files = store.listFiles();
  for (const f of files) if (f.endsWith('.part')) store.remove(f);
  const hasModel = files.some(f => f.toLowerCase().endsWith('.gguf'));
  for (const f of files) if (f.endsWith('.old')) {
    const orig = f.slice(0, -4);
    if (!hasModel && /\.gguf$/i.test(orig)) { try { store.rename(f, orig); } catch { /* keep the .old file rather than lose it */ } }
    else store.remove(f);
  }
}

async function finalize(store: ModelStore, fileName: string, expected: number | null | undefined, opts: InstallOptions) {
  const p = part(fileName);
  try {
    const size = store.sizeOf(p);
    if (size == null || size < MIN_MODEL_BYTES) throw new ModelInstallError('The file is incomplete or is not an AI model. Nothing was changed.');
    if (expected && size !== expected) throw new ModelInstallError(`The file is incomplete (${(size / MB).toFixed(0)} MB of ${(expected / MB).toFixed(0)} MB). Nothing was changed.`);
    const magic = store.readMagic(p);
    if (magic !== null && magic !== 'GGUF') throw new ModelInstallError('This file is not a GGUF model, so Anna cannot use it. Nothing was changed.');
  } catch (e) { store.remove(p); throw e; }

  await opts.beforeSwap?.();
  const hadSame = store.sizeOf(fileName) != null;
  try {
    if (hadSame) store.rename(fileName, old(fileName));
    store.rename(p, fileName);
  } catch (e: any) {
    try { if (hadSame && store.sizeOf(fileName) == null) store.rename(old(fileName), fileName); } catch {}
    store.remove(p);
    throw new ModelInstallError(`Could not put the new model in place (${e?.message ?? e}). The previous model was kept.`);
  }
  // success: single-model policy, drop the replaced model(s)
  for (const f of store.listFiles()) if (f !== fileName && (/\.gguf$/i.test(f) || f.endsWith('.old'))) store.remove(f);
  return { fileName, bytes: store.sizeOf(fileName) ?? 0 };
}

export async function installFromUrl(store: ModelStore, link: string, opts: InstallOptions = {}) {
  const { url, fileName } = parseModelUrl(link);
  cleanupLeftovers(store);
  const expected = opts.expectedBytes ?? await store.contentLength(url).catch(() => null);
  checkSpace(store.freeBytes(), expected);
  const p = part(fileName); store.remove(p);
  try { await store.download(url, p, n => opts.onProgress?.(n, expected ?? null)); }
  catch (e: any) { store.remove(p); throw new ModelInstallError(`The download did not finish: ${e?.message ?? e}. Nothing was changed.`); }
  return finalize(store, fileName, expected, opts);
}

export async function installFromPickedFile(store: ModelStore, picked: { uri: string; name: string; size?: number | null }, opts: InstallOptions = {}) {
  const fileName = safeModelFileName(picked.name);
  cleanupLeftovers(store);
  const expected = picked.size ?? opts.expectedBytes ?? null;
  checkSpace(store.freeBytes(), expected);
  const p = part(fileName); store.remove(p);
  try { await store.importPicked(picked.uri, p); }
  catch (e: any) { store.remove(p); throw new ModelInstallError(`Could not copy the file: ${e?.message ?? e}. Nothing was changed.`); }
  return finalize(store, fileName, expected, opts);
}

export function removeInstalledModels(store: ModelStore) {
  for (const f of store.listFiles()) if (/\.gguf$/i.test(f) || f.endsWith('.part') || f.endsWith('.old')) store.remove(f);
}
