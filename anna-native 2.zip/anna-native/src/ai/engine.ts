// Local AI engine (llama.cpp via llama.rn). Runs entirely on the phone, no network.
// IMPLEMENTED BUT NOT TESTED on a real iPhone: needs a development build + a .gguf model file.
import { Directory, File, Paths } from 'expo-file-system';

export type ModelStatus = 'downloaded' | 'loading' | 'ready' | 'unavailable';
export interface Turn { role: 'system' | 'user' | 'assistant'; content: string }

export const MODEL_DIR = () => new Directory(Paths.document, 'models');
let ctx: any = null; let loading: Promise<void> | null = null; let lastError: string | null = null;

export function findModelFile(): File | null {
  try {
    const dir = MODEL_DIR(); if (!dir.exists) return null;
    const f = dir.list().find(x => x instanceof File && x.uri.toLowerCase().endsWith('.gguf'));
    return (f as File) ?? null;
  } catch { return null; }
}
export const modelName = () => { const f = findModelFile(); return f ? decodeURIComponent(f.uri.split('/').pop() ?? '') : null; };
export const lastEngineError = () => lastError;

export function getStatus(): ModelStatus {
  if (ctx) return 'ready'; if (loading) return 'loading';
  return findModelFile() ? 'downloaded' : 'unavailable';
}
export function whyUnavailable(): string {
  if (!findModelFile()) return 'No AI model file is installed yet. Anna can still save memories, but she cannot write answers until a model is added.';
  return lastError ?? 'The AI model is installed but not loaded.';
}

export async function loadModel(): Promise<void> {
  if (ctx) return; if (loading) return loading;
  const file = findModelFile(); if (!file) throw new Error(whyUnavailable());
  loading = (async () => {
    let initLlama: any;
    try { initLlama = require('llama.rn').initLlama; }
    catch { throw new Error('The on-device AI needs the installed Anna app (a development build). It cannot run inside Expo Go.'); }
    ctx = await initLlama({ model: file.uri, n_ctx: 2048, n_gpu_layers: 99, use_mlock: false });
  })().then(() => { lastError = null; }).catch(e => { ctx = null; lastError = e?.message ?? String(e); throw e; }).finally(() => { loading = null; });
  return loading;
}
export async function unloadModel() { try { await ctx?.release?.(); } finally { ctx = null; } }

export async function generate(messages: Turn[], onToken: (t: string) => void, maxTokens = 512): Promise<string> {
  await loadModel();
  const r = await ctx.completion({ messages, n_predict: maxTokens, temperature: 0.6, stop: ['</s>', '<|im_end|>', '<|eot_id|>'] },
    (d: { token: string }) => onToken(d.token));
  return String(r.text ?? '').trim();
}
export const ANNA_SYSTEM_PROMPT =
  'You are Anna, a warm, concise personal assistant running privately on the user’s phone. ' +
  'Use the saved memories you are given. Treat UNCONFIRMED ASSUMPTIONS as guesses to check, never as facts. ' +
  'If you do not know something, say so instead of guessing.';
