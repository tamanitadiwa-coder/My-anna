// Phone-side file access for model installation (expo-file-system). The rules live in modelInstaller.ts (unit-tested).
// NOT TESTED ON A DEVICE: needs a real iPhone build. Written against the same expo-file-system calls the backup code uses,
// plus File.downloadFileAsync, which is looked up at run time so an API difference shows a clear message instead of a crash.
import { File, Paths } from 'expo-file-system';
import { MODEL_DIR } from './engine';
import { ModelInstallError, ModelStore } from './modelInstaller';

const dir = () => { const d = MODEL_DIR(); if (!d.exists) d.create({ intermediates: true } as any); return d; };
const fileOf = (name: string) => new File(dir(), name);
const baseName = (uri: string) => { const last = uri.split('/').pop() ?? ''; try { return decodeURIComponent(last); } catch { return last; } };

export const modelStore: ModelStore = {
  freeBytes: () => { try { return Paths.availableDiskSpace; } catch { return null; } },
  listFiles: () => { try { return dir().list().filter(x => x instanceof File).map(x => baseName(x.uri)); } catch { return []; } },
  sizeOf: name => { try { const f = fileOf(name); return f.exists ? (f.size ?? 0) : null; } catch { return null; } },
  remove: name => { try { const f = fileOf(name); if (f.exists) f.delete(); } catch { /* already gone */ } },
  rename: (from, to) => { fileOf(from).move(fileOf(to)); },
  readMagic: name => {
    try {
      const h = (fileOf(name) as any).open?.(); if (!h) return null;
      try { const b: Uint8Array = h.readBytes(4); return String.fromCharCode(...Array.from(b)); } finally { h.close?.(); }
    } catch { return null; }
  },
  contentLength: async url => {
    try { const r = await fetch(url, { method: 'HEAD' }); const n = Number(r.headers.get('content-length')); return r.ok && n > 0 ? n : null; }
    catch { return null; }
  },
  download: async (url, intoName, onBytes) => {
    const dl = (File as any).downloadFileAsync;
    if (typeof dl !== 'function') throw new ModelInstallError('This version of Expo cannot download files this way. Use “Import from Files” instead.');
    const dest = fileOf(intoName); if (dest.exists) dest.delete();
    const timer = setInterval(() => { try { if (dest.exists) onBytes(dest.size ?? 0); } catch { /* progress is best effort */ } }, 700);
    try { await dl.call(File, url, dest); } finally { clearInterval(timer); }
  },
  importPicked: async (srcUri, intoName) => { new File(srcUri).move(fileOf(intoName)); },
};
