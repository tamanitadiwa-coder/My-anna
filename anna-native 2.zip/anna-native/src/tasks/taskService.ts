import type { Db } from '../db/types';
import { cleanText, InputError, uid } from '../util/validation';
import { addDays, startOfDay } from '../util/dates';

export type Priority = 'low' | 'normal' | 'high';
export interface Task { id: string; title: string; notes: string | null; due_at: number | null; priority: Priority; completed: 0 | 1; completed_at: number | null; created_at: number; updated_at: number }
const PRIORITIES: Priority[] = ['low', 'normal', 'high'];

export async function addTask(db: Db, p: { title: string; notes?: string; dueAt?: number | null; priority?: Priority }) {
  const title = cleanText(p.title, 'a task', 200)!; const notes = cleanText(p.notes, 'notes', 2000, false);
  const priority = p.priority ?? 'normal'; if (!PRIORITIES.includes(priority)) throw new InputError('Unknown priority.');
  // Duplicate-submission protection: the same open task is saved once.
  const dup = await db.getFirstAsync<{ id: string }>(`SELECT id FROM tasks WHERE completed=0 AND lower(title)=lower(?)`, title);
  if (dup) return dup.id;
  const id = uid(), t = Date.now();
  await db.runAsync(`INSERT INTO tasks(id,title,notes,due_at,priority,completed,completed_at,created_at,updated_at) VALUES(?,?,?,?,?,0,NULL,?,?)`,
    id, title, notes, p.dueAt ?? null, priority, t, t);
  return id;
}

export async function updateTask(db: Db, id: string, p: { title?: string; notes?: string | null; dueAt?: number | null; priority?: Priority }) {
  const cur = await db.getFirstAsync<Task>(`SELECT * FROM tasks WHERE id=?`, id);
  if (!cur) throw new InputError('That task no longer exists.');
  if (p.priority && !PRIORITIES.includes(p.priority)) throw new InputError('Unknown priority.');
  await db.runAsync(`UPDATE tasks SET title=?, notes=?, due_at=?, priority=?, updated_at=? WHERE id=?`,
    p.title !== undefined ? cleanText(p.title, 'a task', 200)! : cur.title,
    p.notes !== undefined ? cleanText(p.notes, 'notes', 2000, false) : cur.notes,
    p.dueAt !== undefined ? p.dueAt : cur.due_at, p.priority ?? cur.priority, Date.now(), id);
}

export async function setTaskCompleted(db: Db, id: string, done: boolean) {
  const t = Date.now();
  const r = await db.runAsync(`UPDATE tasks SET completed=?, completed_at=?, updated_at=? WHERE id=?`, done ? 1 : 0, done ? t : null, t, id);
  if (!r.changes) throw new InputError('That task no longer exists.');
}
export const deleteTask = (db: Db, id: string) => db.runAsync(`DELETE FROM tasks WHERE id=?`, id);

export function listTasks(db: Db, filter: 'open' | 'done' | 'all' = 'open') {
  const where = filter === 'open' ? 'WHERE completed=0' : filter === 'done' ? 'WHERE completed=1' : '';
  return db.getAllAsync<Task>(`SELECT * FROM tasks ${where}
    ORDER BY completed, (due_at IS NULL), due_at, CASE priority WHEN 'high' THEN 0 WHEN 'normal' THEN 1 ELSE 2 END, created_at`);
}

export async function taskSummary(db: Db, now = Date.now()) {
  const today = startOfDay(now), tomorrow = addDays(now, 1);
  const c = async (sql: string, ...a: any[]) => (await db.getFirstAsync<{ c: number }>(sql, ...a))!.c;
  return {
    open: await c(`SELECT COUNT(*) c FROM tasks WHERE completed=0`),
    done: await c(`SELECT COUNT(*) c FROM tasks WHERE completed=1`),
    overdue: await c(`SELECT COUNT(*) c FROM tasks WHERE completed=0 AND due_at IS NOT NULL AND due_at < ?`, today),
    dueToday: await c(`SELECT COUNT(*) c FROM tasks WHERE completed=0 AND due_at >= ? AND due_at < ?`, today, tomorrow),
  };
}
