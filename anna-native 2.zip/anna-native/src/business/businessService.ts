import type { Db } from '../db/types';
import { cleanText, InputError, uid } from '../util/validation';
import { MAX_CENTS } from '../util/money';
import { startOfDay, startOfMonth, startOfNextMonth } from '../util/dates';

export type RecordKind = 'sale' | 'expense' | 'invoice';
export interface BusinessRecord { id: string; kind: RecordKind; party: string | null; description: string; amount_cents: number; status: 'paid' | 'unpaid'; occurred_at: number; due_at: number | null; paid_at: number | null; created_at: number; updated_at: number }
const KINDS: RecordKind[] = ['sale', 'expense', 'invoice'];

/** Sales and expenses are always paid. Invoices start unpaid ("owed to you") until you mark them paid. */
export async function addRecord(db: Db, p: { kind: RecordKind; description: string; amountCents: number; party?: string; occurredAt?: number; dueAt?: number | null }) {
  if (!KINDS.includes(p.kind)) throw new InputError('Unknown record type.');
  if (!Number.isInteger(p.amountCents) || p.amountCents <= 0 || p.amountCents > MAX_CENTS) throw new InputError('Please enter an amount greater than zero.');
  const description = cleanText(p.description, 'a description', 200)!; const party = cleanText(p.party, 'a name', 100, false);
  const id = uid(), t = Date.now(); const unpaid = p.kind === 'invoice';
  await db.runAsync(`INSERT INTO business_records(id,kind,party,description,amount_cents,status,occurred_at,due_at,paid_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`,
    id, p.kind, party, description, p.amountCents, unpaid ? 'unpaid' : 'paid', p.occurredAt ?? t, p.kind === 'invoice' ? (p.dueAt ?? null) : null, unpaid ? null : (p.occurredAt ?? t), t, t);
  return id;
}

export async function markInvoicePaid(db: Db, id: string, now = Date.now()) {
  const r = await db.getFirstAsync<BusinessRecord>(`SELECT * FROM business_records WHERE id=?`, id);
  if (!r) throw new InputError('That record no longer exists.');
  if (r.kind !== 'invoice') throw new InputError('Only invoices can be marked as paid.');
  if (r.status === 'paid') throw new InputError('That invoice is already paid.');
  await db.runAsync(`UPDATE business_records SET status='paid', paid_at=?, updated_at=? WHERE id=?`, now, now, id);
}
export const deleteRecord = (db: Db, id: string) => db.runAsync(`DELETE FROM business_records WHERE id=?`, id);
export const listRecords = (db: Db, kind?: RecordKind, limit = 60) =>
  db.getAllAsync<BusinessRecord>(`SELECT * FROM business_records ${kind ? 'WHERE kind=?' : ''} ORDER BY occurred_at DESC, created_at DESC LIMIT ?`, ...(kind ? [kind, limit] : [limit]));

/**
 * Cash basis: a sale counts on the day it happened; an invoice counts when it is paid (not when it is issued).
 * Outstanding = invoices not yet paid, regardless of month.
 */
export async function businessSummary(db: Db, now = Date.now()) {
  const from = startOfMonth(now), to = startOfNextMonth(now), today = startOfDay(now);
  const s = async (sql: string, ...a: any[]) => (await db.getFirstAsync<{ s: number | null }>(sql, ...a))!.s ?? 0;
  const sales = await s(`SELECT SUM(amount_cents) s FROM business_records WHERE kind='sale' AND occurred_at>=? AND occurred_at<?`, from, to);
  const invoicesPaid = await s(`SELECT SUM(amount_cents) s FROM business_records WHERE kind='invoice' AND status='paid' AND paid_at>=? AND paid_at<?`, from, to);
  const expenses = await s(`SELECT SUM(amount_cents) s FROM business_records WHERE kind='expense' AND occurred_at>=? AND occurred_at<?`, from, to);
  const o = (await db.getFirstAsync<{ n: number; total: number | null; late: number }>(
    `SELECT COUNT(*) n, SUM(amount_cents) total, SUM(CASE WHEN due_at IS NOT NULL AND due_at < ? THEN 1 ELSE 0 END) late
     FROM business_records WHERE kind='invoice' AND status='unpaid'`, today))!;
  const revenue = sales + invoicesPaid;
  return { revenue, expenses, profit: revenue - expenses, outstandingCount: o.n, outstandingCents: o.total ?? 0, overdueCount: o.late ?? 0 };
}
