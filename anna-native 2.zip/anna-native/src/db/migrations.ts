import type { Db } from './types';

/**
 * Schema versions. NEVER edit an old migration once shipped: add a new one at the end.
 * The database remembers its version in PRAGMA user_version.
 */
export const MIGRATIONS: { version: number; sql: string }[] = [
  {
    version: 1,
    sql: `
    CREATE TABLE IF NOT EXISTS conversations(
      id TEXT PRIMARY KEY, title TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS messages(
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      role TEXT NOT NULL CHECK(role IN ('user','assistant','system')),
      content TEXT NOT NULL, memory_ids TEXT, created_at INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversation_id, created_at);
    CREATE TABLE IF NOT EXISTS brain_memories(
      id TEXT PRIMARY KEY, category TEXT NOT NULL, content TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('confirmed','temporary','assumption')),
      source TEXT NOT NULL DEFAULT 'manual', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
      expires_at INTEGER, use_count INTEGER NOT NULL DEFAULT 0, helpful_count INTEGER NOT NULL DEFAULT 0,
      incorrect_count INTEGER NOT NULL DEFAULT 0, last_used_at INTEGER);
    CREATE INDEX IF NOT EXISTS idx_bm_cat ON brain_memories(category);
    CREATE TABLE IF NOT EXISTS brain_feedback(
      id TEXT PRIMARY KEY, message_id TEXT, rating TEXT NOT NULL, memory_ids TEXT, created_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS brain_events(
      id TEXT PRIMARY KEY, type TEXT NOT NULL, title TEXT NOT NULL, detail TEXT, created_at INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_be_time ON brain_events(created_at);
    CREATE TABLE IF NOT EXISTS brain_meta(key TEXT PRIMARY KEY, value TEXT);`,
  },
  {
    // Stage 3: Tasks, Money, Business. Money is stored in whole cents (integers) so totals never drift.
    version: 2,
    sql: `
    CREATE TABLE IF NOT EXISTS tasks(
      id TEXT PRIMARY KEY, title TEXT NOT NULL, notes TEXT, due_at INTEGER,
      priority TEXT NOT NULL DEFAULT 'normal' CHECK(priority IN ('low','normal','high')),
      completed INTEGER NOT NULL DEFAULT 0 CHECK(completed IN (0,1)), completed_at INTEGER,
      created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_tasks_open ON tasks(completed, due_at);
    CREATE TABLE IF NOT EXISTS transactions(
      id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('income','expense')),
      amount_cents INTEGER NOT NULL CHECK(amount_cents > 0), category TEXT NOT NULL DEFAULT 'General', note TEXT,
      occurred_at INTEGER NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_tx_time ON transactions(occurred_at);
    CREATE TABLE IF NOT EXISTS bills(
      id TEXT PRIMARY KEY, name TEXT NOT NULL, amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
      due_at INTEGER NOT NULL, repeat_monthly INTEGER NOT NULL DEFAULT 0 CHECK(repeat_monthly IN (0,1)),
      paid INTEGER NOT NULL DEFAULT 0 CHECK(paid IN (0,1)), paid_at INTEGER,
      created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_bills_due ON bills(paid, due_at);
    CREATE TABLE IF NOT EXISTS budgets(
      id TEXT PRIMARY KEY, category TEXT NOT NULL UNIQUE COLLATE NOCASE,
      limit_cents INTEGER NOT NULL CHECK(limit_cents > 0), created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS business_records(
      id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('sale','expense','invoice')),
      party TEXT, description TEXT NOT NULL, amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
      status TEXT NOT NULL DEFAULT 'paid' CHECK(status IN ('paid','unpaid')),
      occurred_at INTEGER NOT NULL, due_at INTEGER, paid_at INTEGER,
      created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
      CHECK(kind = 'invoice' OR status = 'paid'));
    CREATE INDEX IF NOT EXISTS idx_br_time ON business_records(occurred_at);
    CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY, value TEXT);`,
  },
];
export const LATEST_VERSION = MIGRATIONS[MIGRATIONS.length - 1].version;

export class DatabaseTooNewError extends Error {}

/** Runs any missing migrations, each inside its own transaction. Existing data is never dropped. */
export async function migrate(db: Db): Promise<{ from: number; to: number }> {
  const row = await db.getFirstAsync<{ user_version: number }>('PRAGMA user_version');
  const from = row?.user_version ?? 0;
  if (from > LATEST_VERSION)
    throw new DatabaseTooNewError(`This data was created by a newer version of Anna (schema ${from}). Update the app before opening it.`);
  for (const m of MIGRATIONS.filter(m => m.version > from)) {
    await db.withTransactionAsync(async () => {
      await db.execAsync(m.sql);
      await db.execAsync(`PRAGMA user_version = ${m.version}`);
    });
  }
  return { from, to: LATEST_VERSION };
}

export async function integrityCheck(db: Db): Promise<{ ok: boolean; detail: string }> {
  const rows = await db.getAllAsync<{ integrity_check: string }>('PRAGMA integrity_check');
  const detail = rows.map(r => r.integrity_check).join('; ');
  return { ok: detail === 'ok', detail };
}
