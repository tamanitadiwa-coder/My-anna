import * as SQLite from 'expo-sqlite';
import type { Db } from './types';
import { migrate } from './migrations';

export const DB_NAME = 'anna.db';
let opening: Promise<SQLite.SQLiteDatabase> | null = null;

/** The ONE database for the whole app. Opens once, enables safety settings, runs migrations. */
export function getDb(): Promise<SQLite.SQLiteDatabase & Db> {
  if (!opening) {
    opening = (async () => {
      const db = await SQLite.openDatabaseAsync(DB_NAME);
      await db.execAsync('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
      await migrate(db as unknown as Db);
      return db;
    })().catch(e => { opening = null; throw e; }); // allow a retry after a failure
  }
  return opening as Promise<SQLite.SQLiteDatabase & Db>;
}
