import React, { useCallback, useState } from 'react';
import { Alert, ScrollView, Text, View } from 'react-native';
import { getDb } from '../db/database';
import { C } from '../theme';
import * as M from '../money/moneyService';
import { formatCents, parseAmountToCents } from '../util/money';
import { formatDate, parseDateInput, startOfDay } from '../util/dates';
import { Bar, Btn, Body, Card, Chip, confirmDelete, DateField, Field, H1, H2, k, Mute, Seg, Stat, useScreenData } from '../ui/kit';

type View_ = 'overview' | 'bills' | 'budgets';
const needAmount = (s: string) => { const c = parseAmountToCents(s); if (c == null) throw new Error('Please enter an amount greater than zero, like 250 or 1,250.50.'); return c; };

export default function MoneyScreen() {
  const [view, setView] = useState<View_>('overview');
  const [sym, setSym] = useState(''); const [symDraft, setSymDraft] = useState('');
  const [month, setMonth] = useState<Awaited<ReturnType<typeof M.monthSummary>> | null>(null);
  const [txs, setTxs] = useState<M.Transaction[]>([]); const [bills, setBills] = useState<M.Bill[]>([]);
  const [bsum, setBsum] = useState({ unpaid: 0, unpaidCents: 0, overdue: 0, dueWithin7Days: 0 });
  const [budgets, setBudgets] = useState<Awaited<ReturnType<typeof M.budgetStatus>>>([]);
  // forms
  const [kind, setKind] = useState<'income' | 'expense'>('expense'); const [amt, setAmt] = useState(''); const [cat, setCat] = useState(''); const [note, setNote] = useState('');
  const [bName, setBName] = useState(''); const [bAmt, setBAmt] = useState(''); const [bDue, setBDue] = useState(''); const [bMonthly, setBMonthly] = useState(false);
  const [gCat, setGCat] = useState(''); const [gAmt, setGAmt] = useState('');

  const load = useCallback(async () => {
    const db = await getDb(); const c = await M.getCurrency(db); setSym(c); setSymDraft(prev => (prev === '' ? c : prev));
    setMonth(await M.monthSummary(db)); setTxs(await M.listTransactions(db, 30));
    setBills(await M.listBills(db)); setBsum(await M.billSummary(db)); setBudgets(await M.budgetStatus(db));
  }, []);
  const { error, run } = useScreenData(load);
  const f = (c: number) => formatCents(c, sym); const today = startOfDay(Date.now());

  const addTx = () => run(async () => { await M.addTransaction(await getDb(), { kind, amountCents: needAmount(amt), category: cat, note }); setAmt(''); setNote(''); });
  const addBill = () => run(async () => {
    const dueAt = parseDateInput(bDue); if (dueAt == null) throw new Error('Please write the due date like 2026-12-31, or tap a quick date.');
    await M.addBill(await getDb(), { name: bName, amountCents: needAmount(bAmt), dueAt, repeatMonthly: bMonthly }); setBName(''); setBAmt(''); setBDue(''); setBMonthly(false);
  });
  const addBudget = () => run(async () => { await M.setBudget(await getDb(), gCat, needAmount(gAmt)); setGCat(''); setGAmt(''); });
  const pay = (b: M.Bill) => Alert.alert(`Mark “${b.name}” as paid?`, `${f(b.amount_cents)}. You can also record it as an expense so your totals stay correct.`, [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Paid only', onPress: () => run(async () => M.markBillPaid(await getDb(), b.id)) },
    { text: 'Paid + record expense', onPress: () => run(async () => M.markBillPaid(await getDb(), b.id, { recordExpense: true })) }]);

  return (
    <ScrollView style={k.root} contentContainerStyle={{ padding: 18, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
      <H1>Money</H1><Mute>Your personal income, spending, bills and budgets. Stored only on this iPhone.</Mute>
      <Seg value={view} onChange={setView} options={[{ key: 'overview', label: 'This month' }, { key: 'bills', label: 'Bills' }, { key: 'budgets', label: 'Budgets' }]} />
      {error && <Text style={k.err}>{error}</Text>}

      {view === 'overview' && month && (<>
        <View style={k.grid}><Stat label="Income" value={f(month.income)} /><Stat label="Spent" value={f(month.expense)} />
          <Stat label="Left over" value={f(month.net)} tone={month.net < 0 ? 'bad' : undefined} /><Stat label="Bills unpaid" value={f(bsum.unpaidCents)} tone={bsum.overdue ? 'bad' : undefined} /></View>
        {month.byCategory.length > 0 && <Card>{month.byCategory.map(c => <View key={c.category} style={[k.between, { paddingVertical: 3 }]}><Body>{c.category}</Body><Mute>{f(c.total)}</Mute></View>)}</Card>}

        <H2>Add income or expense</H2>
        <Card>
          <Seg value={kind} onChange={setKind} options={[{ key: 'expense', label: 'Expense' }, { key: 'income', label: 'Income' }]} />
          <Field label="Amount" value={amt} onChangeText={setAmt} placeholder="e.g. 250.00" keyboardType="decimal-pad" />
          <Field label="Category (optional)" value={cat} onChangeText={setCat} placeholder="e.g. Food, Transport, Salary" maxLength={60} />
          <Field label="Note (optional)" value={note} onChangeText={setNote} maxLength={300} />
          <Btn label={kind === 'income' ? 'Save income' : 'Save expense'} onPress={addTx} />
        </Card>

        <H2>Recent</H2>
        {txs.length === 0 && <Card><Mute>Nothing recorded yet.</Mute></Card>}
        {txs.map(t => (
          <Card key={t.id}><View style={k.between}>
            <View style={{ flex: 1 }}><Body>{t.category}{t.note ? ` · ${t.note}` : ''}</Body><Mute>{formatDate(t.occurred_at)}</Mute></View>
            <Text style={{ color: t.kind === 'income' ? C.sageDark : C.ink, fontWeight: '600' }}>{t.kind === 'income' ? '+' : '−'}{f(t.amount_cents)}</Text></View>
            <View style={[k.row, { marginTop: 4 }]}><Btn small ghost label="Delete" onPress={() => confirmDelete('Delete this entry?', `${t.category} ${f(t.amount_cents)}`, () => run(async () => { await M.deleteTransaction(await getDb(), t.id); }))} /></View></Card>))}

        <H2>Currency symbol</H2>
        <Card><Field value={symDraft} onChangeText={setSymDraft} placeholder="e.g. R, $, €  (optional)" maxLength={5} />
          <Btn ghost label="Save symbol" onPress={() => run(async () => { await M.setCurrency(await getDb(), symDraft); })} /></Card>
      </>)}

      {view === 'bills' && (<>
        <View style={k.grid}><Stat label="Unpaid" value={String(bsum.unpaid)} /><Stat label="Overdue" value={String(bsum.overdue)} tone={bsum.overdue ? 'bad' : undefined} />
          <Stat label="Due in 7 days" value={String(bsum.dueWithin7Days)} /><Stat label="Total unpaid" value={f(bsum.unpaidCents)} /></View>
        <H2>Add a bill</H2>
        <Card>
          <Field label="Name" value={bName} onChangeText={setBName} placeholder="e.g. Rent, Phone, Insurance" maxLength={100} />
          <Field label="Amount" value={bAmt} onChangeText={setBAmt} keyboardType="decimal-pad" />
          <DateField label="Due date" value={bDue} onChangeText={setBDue} />
          <View style={k.chips}><Chip label={bMonthly ? '✓ Repeats every month' : 'Repeats every month?'} on={bMonthly} onPress={() => setBMonthly(!bMonthly)} /></View>
          <Btn label="Add bill" onPress={addBill} />
        </Card>
        <H2>Unpaid bills</H2>
        {bills.length === 0 && <Card><Mute>No unpaid bills.</Mute></Card>}
        {bills.map(b => (
          <Card key={b.id}><View style={k.between}>
            <View style={{ flex: 1 }}><Body>{b.name}</Body><Mute style={b.due_at < today ? { color: C.danger } : undefined}>{b.due_at < today ? 'Overdue · ' : 'Due '}{formatDate(b.due_at)}{b.repeat_monthly ? ' · monthly' : ''}</Mute></View>
            <Text style={{ fontWeight: '600', color: C.ink }}>{f(b.amount_cents)}</Text></View>
            <View style={[k.row, { gap: 8, marginTop: 4 }]}><Btn small label="Mark paid" onPress={() => pay(b)} />
              <Btn small ghost label="Delete" onPress={() => confirmDelete('Delete this bill?', b.name, () => run(async () => { await M.deleteBill(await getDb(), b.id); }))} /></View></Card>))}
      </>)}

      {view === 'budgets' && (<>
        <H2>Set a monthly budget</H2>
        <Card>
          <Field label="Category (same name you use for expenses)" value={gCat} onChangeText={setGCat} placeholder="e.g. Food" maxLength={60} />
          <Field label="Monthly limit" value={gAmt} onChangeText={setGAmt} keyboardType="decimal-pad" />
          <Btn label="Save budget" onPress={addBudget} /><Mute style={{ marginTop: 6 }}>Saving a category that already has a budget changes its limit.</Mute>
        </Card>
        <H2>This month</H2>
        {budgets.length === 0 && <Card><Mute>No budgets yet.</Mute></Card>}
        {budgets.map(b => (
          <Card key={b.id}>
            <View style={k.between}><Body>{b.category}</Body><Mute style={b.over ? { color: C.danger } : undefined}>{f(b.spent)} of {f(b.limit_cents)}</Mute></View>
            <Bar value={b.used} over={b.over} />
            <Mute style={{ marginTop: 4 }}>{b.over ? `Over by ${f(-b.remaining)}` : `${f(b.remaining)} left`}</Mute>
            <View style={[k.row, { marginTop: 4 }]}><Btn small ghost label="Remove" onPress={() => confirmDelete('Remove this budget?', b.category, () => run(async () => { await M.deleteBudget(await getDb(), b.id); }))} /></View>
          </Card>))}
      </>)}
    </ScrollView>);
}
