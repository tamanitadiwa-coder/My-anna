import React, { useCallback, useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { getDb } from '../db/database';
import { C } from '../theme';
import * as T from '../tasks/taskService';
import { formatDate, parseDateInput, startOfDay } from '../util/dates';
import { Btn, Body, Card, Chip, confirmDelete, DateField, Field, H1, H2, k, Mute, Seg, Stat, useScreenData } from '../ui/kit';

const PRI: { key: T.Priority; label: string }[] = [{ key: 'high', label: 'High' }, { key: 'normal', label: 'Normal' }, { key: 'low', label: 'Low' }];

export default function TasksScreen() {
  const [tasks, setTasks] = useState<T.Task[]>([]);
  const [sum, setSum] = useState({ open: 0, done: 0, overdue: 0, dueToday: 0 });
  const [filter, setFilter] = useState<'open' | 'done'>('open');
  const [title, setTitle] = useState(''); const [notes, setNotes] = useState(''); const [due, setDue] = useState(''); const [pri, setPri] = useState<T.Priority>('normal');

  const load = useCallback(async () => { const db = await getDb(); setTasks(await T.listTasks(db, filter)); setSum(await T.taskSummary(db)); }, [filter]);
  const { error, run } = useScreenData(load);

  const add = () => run(async () => {
    let dueAt: number | null = null;
    if (due.trim()) { dueAt = parseDateInput(due); if (dueAt == null) throw new Error('Please write the date like 2026-12-31, or tap Today / Tomorrow.'); }
    await T.addTask(await getDb(), { title, notes, dueAt, priority: pri });
    setTitle(''); setNotes(''); setDue(''); setPri('normal');
  });
  const today = startOfDay(Date.now());

  return (
    <ScrollView style={k.root} contentContainerStyle={{ padding: 18, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
      <H1>Tasks</H1><Mute>Everything is saved on this iPhone.</Mute>
      <View style={[k.grid, { marginTop: 12 }]}>
        <Stat label="Open" value={String(sum.open)} /><Stat label="Overdue" value={String(sum.overdue)} tone={sum.overdue ? 'bad' : undefined} />
        <Stat label="Due today" value={String(sum.dueToday)} /><Stat label="Completed" value={String(sum.done)} />
      </View>

      <H2>Add a task</H2>
      <Card>
        <Field label="What needs doing?" value={title} onChangeText={setTitle} placeholder="e.g. Send the quote to a customer" maxLength={200} />
        <Field label="Notes (optional)" value={notes} onChangeText={setNotes} multiline maxLength={2000} />
        <DateField label="Due date (optional)" value={due} onChangeText={setDue} />
        <Mute>Priority</Mute>
        <View style={k.chips}>{PRI.map(p => <Chip key={p.key} label={p.label} on={pri === p.key} onPress={() => setPri(p.key)} />)}</View>
        <Btn label="Add task" onPress={add} />
      </Card>

      <H2>Your tasks</H2>
      <Seg value={filter} onChange={setFilter} options={[{ key: 'open', label: 'Open' }, { key: 'done', label: 'Done' }]} />
      {error && <Text style={k.err}>{error}</Text>}
      {tasks.length === 0 && <Card><Mute>{filter === 'open' ? 'No open tasks. Add one above.' : 'Nothing completed yet.'}</Mute></Card>}
      {tasks.map(t => {
        const overdue = !t.completed && t.due_at != null && t.due_at < today;
        return (
          <Card key={t.id}>
            <Pressable style={k.row} onPress={() => run(async () => T.setTaskCompleted(await getDb(), t.id, !t.completed))} accessibilityRole="checkbox" accessibilityState={{ checked: !!t.completed }}>
              <View style={{ width: 24, height: 24, borderRadius: 12, borderWidth: 2, borderColor: C.sage, marginRight: 12, backgroundColor: t.completed ? C.sage : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
                {!!t.completed && <Text style={{ color: '#fff', fontSize: 14 }}>✓</Text>}</View>
              <View style={{ flex: 1 }}>
                <Body style={t.completed ? { textDecorationLine: 'line-through', color: C.mute } : undefined}>{t.title}</Body>
                <Mute style={overdue ? { color: C.danger } : undefined}>
                  {[t.due_at != null ? `${overdue ? 'Overdue · ' : 'Due '}${formatDate(t.due_at)}` : null, t.priority === 'high' ? 'High priority' : t.priority === 'low' ? 'Low priority' : null].filter(Boolean).join(' · ') || 'No due date'}</Mute>
              </View>
            </Pressable>
            {!!t.notes && <Mute style={{ marginTop: 6 }}>{t.notes}</Mute>}
            <View style={[k.row, { gap: 8, marginTop: 4 }]}>
              <Btn small ghost label="Delete" onPress={() => confirmDelete('Delete this task?', t.title, () => run(async () => { await T.deleteTask(await getDb(), t.id); }))} />
            </View>
          </Card>);
      })}
    </ScrollView>);
}
