import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { getDb } from '../db/database';
import { C } from '../theme';
import { addMessage, ChatMessage, createConversation, latestConversationId, listMessages, MAX_MESSAGE_CHARS, parseIds } from '../chat/chatService';
import { buildPromptContext, retrieveRelevant } from '../brain/brainService';
import AnswerFeedback from '../brain/AnswerFeedback';
import * as engine from '../ai/engine';
import { dataEvents } from '../util/events';

export default function ChatScreen() {
  const [convId, setConvId] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [draft, setDraft] = useState<string | null>(null); // assistant text while it is being written
  const [error, setError] = useState<string | null>(null);
  const sendingRef = useRef(false);
  const list = useRef<FlatList<ChatMessage>>(null);

  const load = useCallback(async () => {
    try {
      const db = await getDb(); const id = await latestConversationId(db);
      setConvId(id); setMsgs(id ? await listMessages(db, id) : []); setError(null);
    } catch (e: any) { setError(e?.message ?? String(e)); }
  }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => dataEvents.subscribe(() => { load(); }), [load]);

  const send = async () => {
    const text = input.trim();
    if (!text || sendingRef.current) return; // blocks empty messages and double-taps
    if (text.length > MAX_MESSAGE_CHARS) { setError(`Messages can be up to ${MAX_MESSAGE_CHARS} characters.`); return; }
    sendingRef.current = true; setSending(true); setError(null); setInput('');
    try {
      const db = await getDb();
      const id = convId ?? await createConversation(db, text); setConvId(id);
      await addMessage(db, id, 'user', text); setMsgs(await listMessages(db, id));
      const mems = await retrieveRelevant(text); const memIds = mems.map(m => m.id);
      if (engine.getStatus() === 'unavailable') {
        await addMessage(db, id, 'system', engine.whyUnavailable());
      } else {
        const history = (await listMessages(db, id)).filter(m => m.role !== 'system').slice(-12).map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }));
        const ctx = buildPromptContext(mems);
        setDraft('');
        let acc = '';
        try {
          const answer = await engine.generate([{ role: 'system', content: engine.ANNA_SYSTEM_PROMPT + (ctx ? '\n\n' + ctx : '') }, ...history],
            t => { acc += t; setDraft(acc); });
          await addMessage(db, id, 'assistant', answer || acc || '(no answer)', memIds);
        } catch (e: any) {
          await addMessage(db, id, 'system', `Anna could not answer: ${e?.message ?? e}`);
        } finally { setDraft(null); }
      }
      setMsgs(await listMessages(db, id));
    } catch (e: any) { setError(e?.message ?? String(e)); setInput(text); }
    finally { sendingRef.current = false; setSending(false); }
  };

  const newChat = () => { if (!sending) { setConvId(null); setMsgs([]); setError(null); } };

  return (
    <KeyboardAvoidingView style={s.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={s.header}><Text style={s.title}>Anna</Text><Pressable onPress={newChat}><Text style={s.link}>New chat</Text></Pressable></View>
      <FlatList ref={list} data={msgs} keyExtractor={m => m.id} contentContainerStyle={{ padding: 14, flexGrow: 1 }}
        onContentSizeChange={() => list.current?.scrollToEnd({ animated: true })}
        ListEmptyComponent={<View style={s.empty}><Text style={s.emptyT}>Say hello to Anna</Text>
          <Text style={s.emptyB}>Your chats stay on this iPhone. Teach her things in the Brain tab and she will use them when she answers.</Text></View>}
        renderItem={({ item }) => (
          <View style={[s.row, item.role === 'user' && { alignItems: 'flex-end' }]}>
            <View style={[s.bubble, item.role === 'user' ? s.me : item.role === 'system' ? s.sys : s.anna]}>
              <Text style={[s.txt, item.role === 'user' && { color: '#fff' }]}>{item.content}</Text></View>
            {item.role === 'assistant' && <AnswerFeedback messageId={item.id} memoryIds={parseIds(item.memory_ids)} answerText={item.content} />}
          </View>)}
        ListFooterComponent={draft !== null ? <View style={s.row}><View style={[s.bubble, s.anna]}>{draft ? <Text style={s.txt}>{draft}</Text> : <ActivityIndicator color={C.sage} />}</View></View> : null} />
      {error && <Text style={s.err}>{error}</Text>}
      <View style={s.bar}>
        <TextInput style={s.input} value={input} onChangeText={setInput} placeholder="Message Anna" placeholderTextColor={C.mute} multiline editable={!sending} />
        <Pressable onPress={send} disabled={sending || !input.trim()} style={[s.send, (sending || !input.trim()) && { opacity: 0.4 }]}><Text style={{ color: '#fff', fontWeight: '600' }}>Send</Text></Pressable>
      </View>
    </KeyboardAvoidingView>);
}
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.cream },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 10 },
  title: { fontFamily: Platform.select({ ios: 'Georgia', default: 'serif' }), fontSize: 26, color: C.ink }, link: { color: C.sageDark, fontSize: 14 },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 30 }, emptyT: { fontSize: 18, color: C.ink, marginBottom: 6 }, emptyB: { color: C.mute, textAlign: 'center', lineHeight: 20 },
  row: { marginBottom: 12 }, bubble: { maxWidth: '86%', borderRadius: 16, padding: 12 },
  me: { backgroundColor: C.sage }, anna: { backgroundColor: C.card, borderWidth: 1, borderColor: C.line }, sys: { backgroundColor: C.blueSoft },
  txt: { fontSize: 15, lineHeight: 21, color: C.ink }, err: { color: C.danger, paddingHorizontal: 18, paddingBottom: 6 },
  bar: { flexDirection: 'row', alignItems: 'flex-end', gap: 8, padding: 10, borderTopWidth: 1, borderTopColor: C.line, backgroundColor: C.cream },
  input: { flex: 1, maxHeight: 120, backgroundColor: C.card, borderRadius: 18, borderWidth: 1, borderColor: C.line, paddingHorizontal: 14, paddingVertical: 10, fontSize: 15, color: C.ink },
  send: { backgroundColor: C.sage, borderRadius: 18, paddingHorizontal: 16, paddingVertical: 11 },
});
