import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { getDb } from '../db/database';
import { integrityCheck, LATEST_VERSION } from '../db/migrations';
import { createAndShareBackup, pickBackup, restoreFromPayload, storageInfo } from '../backup/backupFiles';
import { deleteAllAnnaData } from '../brain/brainService';
import * as engine from '../ai/engine';
import { dataEvents } from '../util/events';
import ModelCard from './ModelCard';
import { C } from '../theme';

const mb = (n: number | null) => (n == null ? 'Unknown' : n > 1e9 ? `${(n / 1e9).toFixed(1)} GB` : `${(n / 1e6).toFixed(1)} MB`);

export default function DataScreen() {
  const [info, setInfo] = useState<{ dbBytes: number | null; freeBytes: number | null }>({ dbBytes: null, freeBytes: null });
  const [health, setHealth] = useState<string>('Not checked yet');
  const [model, setModel] = useState({ status: engine.getStatus(), name: engine.modelName() });
  const [busy, setBusy] = useState(false); const lock = useRef(false);
  const refresh = useCallback(async () => { setInfo(await storageInfo()); setModel({ status: engine.getStatus(), name: engine.modelName() }); }, []);
  useEffect(() => { refresh(); }, [refresh]);

  const run = async (fn: () => Promise<string | void>) => {
    if (lock.current) return; lock.current = true; setBusy(true);
    try { const m = await fn(); if (m) Alert.alert(m); } catch (e: any) { Alert.alert('Something went wrong', e?.message ?? String(e)); }
    lock.current = false; setBusy(false); refresh();
  };
  const restore = async () => {
    try {
      const payload = await pickBackup(); if (!payload) return;
      Alert.alert('Restore backup', 'Anna first saves a safety copy of your current data. If anything fails, your current data is left exactly as it is.', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Merge', onPress: () => run(async () => { await restoreFromPayload(payload, 'merge'); dataEvents.emit(); return 'Backup merged'; }) },
        { text: 'Replace', style: 'destructive', onPress: () => run(async () => { await restoreFromPayload(payload, 'replace'); dataEvents.emit(); return 'Backup restored'; }) }]);
    } catch (e: any) { Alert.alert('Cannot restore', e?.message ?? String(e)); }
  };

  return (
    <ScrollView style={s.root} contentContainerStyle={{ padding: 18, paddingBottom: 60 }}>
      <Text style={s.h1}>Data & AI model</Text>
      <Text style={s.sub}>Everything Anna knows lives in one private database on this iPhone.</Text>

      <Text style={s.h2}>AI model</Text>
      <View style={s.card}>
        <Text style={s.t}>Status: {model.status}</Text>
        <Text style={s.mute}>{model.name ?? 'No model file installed'}</Text>
        {model.status === 'unavailable' && <Text style={[s.mute, { marginTop: 6 }]}>{engine.whyUnavailable()}</Text>}
        <Btn ghost label="Check again" onPress={refresh} />
      </View>

      <ModelCard onChanged={refresh} />

      <Text style={s.h2}>Storage & health</Text>
      <View style={s.card}>
        <Row k="Anna’s database" v={mb(info.dbBytes)} /><Row k="Free space on iPhone" v={mb(info.freeBytes)} /><Row k="Database version" v={String(LATEST_VERSION)} />
        <Row k="Integrity check" v={health} />
        <Btn ghost label="Run integrity check" onPress={() => run(async () => { const r = await integrityCheck(await getDb()); setHealth(r.ok ? 'Healthy' : `Problem: ${r.detail}`); })} />
      </View>

      <Text style={s.h2}>Backup & restore</Text>
      <View style={s.card}>
        <Text style={s.mute}>A full backup includes chats and the Brain. It is checked after it is written, so a half-finished backup is never kept.</Text>
        <Btn label="Create full backup" onPress={() => run(async () => { await createAndShareBackup('full', 'backup'); return 'Backup created'; })} />
        <Btn ghost label="Restore from a backup file" onPress={restore} />
      </View>

      <Text style={s.h2}>Danger zone</Text>
      <View style={s.card}>
        <Btn danger label="Delete all Anna data" onPress={() => Alert.alert('Delete everything?', 'All chats, memories and history will be erased from this phone. Create a backup first if you might want them.',
          [{ text: 'Cancel', style: 'cancel' }, { text: 'Delete all', style: 'destructive', onPress: () => run(async () => { await deleteAllAnnaData(); dataEvents.emit(); return 'All data deleted'; }) }])} />
      </View>
      {busy && <Text style={[s.mute, { textAlign: 'center', marginTop: 10 }]}>Working…</Text>}
    </ScrollView>);
}
const Row = ({ k, v }: { k: string; v: string }) => <View style={s.rowB}><Text style={s.t}>{k}</Text><Text style={s.mute}>{v}</Text></View>;
const Btn = ({ label, onPress, ghost, danger }: any) => (
  <Pressable onPress={onPress} style={[s.btn, ghost && s.ghost, danger && { backgroundColor: C.danger, borderColor: C.danger }]}>
    <Text style={{ color: ghost ? C.sageDark : '#fff', fontWeight: '600' }}>{label}</Text></Pressable>);
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.cream }, h1: { fontFamily: Platform.select({ ios: 'Georgia', default: 'serif' }), fontSize: 28, color: C.ink, marginTop: 16 },
  h2: { fontFamily: Platform.select({ ios: 'Georgia', default: 'serif' }), fontSize: 20, color: C.ink, marginTop: 22, marginBottom: 8 }, sub: { color: C.mute, marginTop: 4, lineHeight: 20 },
  card: { backgroundColor: C.card, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: C.line }, t: { fontSize: 14, color: C.ink }, mute: { fontSize: 13, color: C.mute },
  rowB: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 },
  btn: { backgroundColor: C.sage, borderRadius: 12, paddingVertical: 11, alignItems: 'center', borderWidth: 1, borderColor: C.sage, marginTop: 8 }, ghost: { backgroundColor: 'transparent' },
});
