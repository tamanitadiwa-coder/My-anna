import React, { useCallback, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { getDb } from '../db/database';
import { C } from '../theme';
import * as BZ from '../business/businessService';
import * as M from '../money/moneyService';
import { formatCents, parseAmountToCents } from '../util/money';
import { formatDate, parseDateInput, startOfDay } from '../util/dates';
import { Btn, Body, Card, confirmDelete, DateField, Field, H1, H2, k, Mute, Seg, Stat, useScreenData } from '../ui/kit';

const LABEL: Record<BZ.RecordKind, string> = { sale: 'Sale', expense: 'Business expense', invoice: 'Invoice' };

export default function BusinessScreen() {
  const [sum, setSum] = useState<Awaited<ReturnType<typeof BZ.businessSummary>> | null>(null);
  const [rows, setRows] = useState<BZ.BusinessRecord[]>([]); const [sym, setSym] = useState('');
  const [filter, setFilter] = useState<'all' | BZ.RecordKind>('all');
  const [kind, setKind] = useState<BZ.RecordKind>('sale'); const [desc, setDesc] = useState(''); const [party, setParty] = useState(''); const [amt, setAmt] = useState(''); const [due, setDue] = useState('');

  const load = useCallback(async () => {
    const db = await getDb(); setSym(await M.getCurrency(db)); setSum(await BZ.businessSummary(db));
    setRows(await BZ.listRecords(db, filter === 'all' ? undefined : filter));
  }, [filter]);
  const { error, run } = useScreenData(load);
  const f = (c: number) => formatCents(c, sym); const today = startOfDay(Date.now());

  const add = () => run(async () => {
    const cents = parseAmountToCents(amt); if (cents == null) throw new Error('Please enter an amount greater than zero, like 250 or 1,250.50.');
    let dueAt: number | null = null;
    if (kind === 'invoice' && due.trim()) { dueAt = parseDateInput(due); if (dueAt == null) throw new Error('Please write the due date like 2026-12-31, or tap a quick date.'); }
    await BZ.addRecord(await getDb(), { kind, description: desc, amountCents: cents, party, dueAt });
    setDesc(''); setParty(''); setAmt(''); setDue('');
  });

  return (
    <ScrollView style={k.root} contentContainerStyle={{ padding: 18, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
      <H1>Business</H1><Mute>Sales, business expenses and invoices. Kept separate from your personal money. Stored only on this iPhone.</Mute>
      {error && <Text style={k.err}>{error}</Text>}
      {sum && (<>
        <H2>This month</H2>
        <View style={k.grid}><Stat label="Money in" value={f(sum.revenue)} /><Stat label="Money out" value={f(sum.expenses)} />
          <Stat label="Profit" value={f(sum.profit)} tone={sum.profit < 0 ? 'bad' : undefined} /><Stat label={`Owed to you (${sum.outstandingCount})`} value={f(sum.outstandingCents)} tone={sum.overdueCount ? 'bad' : undefined} /></View>
        <Mute>Counted when money actually arrives: a sale on the day it happens, an invoice on the day you mark it paid.{sum.overdueCount ? ` ${sum.overdueCount} invoice${sum.overdueCount === 1 ? ' is' : 's are'} overdue.` : ''}</Mute>
      </>)}

      <H2>Add a record</H2>
      <Card>
        <Seg value={kind} onChange={setKind} options={[{ key: 'sale', label: 'Sale' }, { key: 'expense', label: 'Expense' }, { key: 'invoice', label: 'Invoice' }]} />
        <Field label="Description" value={desc} onChangeText={setDesc} placeholder={kind === 'expense' ? 'e.g. Stock, fuel, rent' : 'e.g. 3 cakes, website design'} maxLength={200} />
        <Field label={kind === 'expense' ? 'Supplier (optional)' : 'Customer (optional)'} value={party} onChangeText={setParty} maxLength={100} />
        <Field label="Amount" value={amt} onChangeText={setAmt} keyboardType="decimal-pad" />
        {kind === 'invoice' && <DateField label="Payment due date (optional)" value={due} onChangeText={setDue} />}
        <Btn label={`Save ${LABEL[kind].toLowerCase()}`} onPress={add} />
        {kind === 'invoice' && <Mute style={{ marginTop: 6 }}>An invoice stays “unpaid” until you mark it paid.</Mute>}
      </Card>

      <H2>Records</H2>
      <Seg value={filter} onChange={setFilter} options={[{ key: 'all', label: 'All' }, { key: 'sale', label: 'Sales' }, { key: 'expense', label: 'Expenses' }, { key: 'invoice', label: 'Invoices' }]} />
      {rows.length === 0 && <Card><Mute>Nothing recorded yet.</Mute></Card>}
      {rows.map(r => {
        const late = r.kind === 'invoice' && r.status === 'unpaid' && r.due_at != null && r.due_at < today;
        return (
          <Card key={r.id}>
            <View style={k.between}>
              <View style={{ flex: 1 }}><Body>{r.description}</Body>
                <Mute style={late ? { color: C.danger } : undefined}>{LABEL[r.kind]}{r.party ? ` · ${r.party}` : ''} · {formatDate(r.occurred_at)}{r.kind === 'invoice' ? (r.status === 'paid' ? ' · paid' : late ? ' · OVERDUE' : r.due_at != null ? ` · due ${formatDate(r.due_at)}` : ' · unpaid') : ''}</Mute></View>
              <Text style={{ fontWeight: '600', color: r.kind === 'expense' ? C.ink : C.sageDark }}>{r.kind === 'expense' ? '−' : '+'}{f(r.amount_cents)}</Text></View>
            <View style={[k.row, { gap: 8, marginTop: 4 }]}>
              {r.kind === 'invoice' && r.status === 'unpaid' && <Btn small label="Mark paid" onPress={() => run(async () => BZ.markInvoicePaid(await getDb(), r.id))} />}
              <Btn small ghost label="Delete" onPress={() => confirmDelete('Delete this record?', r.description, () => run(async () => { await BZ.deleteRecord(await getDb(), r.id); }))} /></View>
          </Card>);
      })}
    </ScrollView>);
}
