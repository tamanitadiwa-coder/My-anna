// Install, replace or remove the on-device AI model. The rules (space check, verify, safe swap) are in ai/modelInstaller.ts.
// NOT TESTED ON A DEVICE: downloading and importing need a real iPhone build.
import React, { useEffect, useRef, useState } from 'react';
import { Alert, Text } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import * as engine from '../ai/engine';
import { modelStore } from '../ai/modelFiles';
import * as I from '../ai/modelInstaller';
import { dataEvents } from '../util/events';
import { Bar, Btn, Card, Field, H2, Mute } from '../ui/kit';

const gb = (n: number) => (n >= I.GB ? `${(n / I.GB).toFixed(2)} GB` : `${Math.round(n / I.MB)} MB`);

export default function ModelCard({ onChanged }: { onChanged: () => void }) {
  const [link, setLink] = useState(''); const [working, setWorking] = useState(false);
  const [progress, setProgress] = useState<{ done: number; total: number | null } | null>(null);
  const [version, setVersion] = useState(0); const lock = useRef(false);
  useEffect(() => { try { I.cleanupLeftovers(modelStore); } catch { /* best effort */ } setVersion(v => v + 1); }, []);

  const name = engine.modelName(); const size = name ? modelStore.sizeOf(name) : null; void version;

  const guarded = async (fn: () => Promise<{ fileName: string; bytes: number } | void>) => {
    if (lock.current) return; lock.current = true; setWorking(true); setProgress(null);
    try { await activateKeepAwakeAsync('anna-model-install'); } catch { /* optional */ }
    try {
      const r = await fn();
      if (r) {
        const warn = I.bigModelWarning(r.bytes);
        Alert.alert('Model installed', `${r.fileName} (${gb(r.bytes)}) is ready. Anna loads it the first time you chat.${warn ? '\n\n' + warn : ''}`);
      }
    } catch (e: any) { Alert.alert('Model not installed', e?.message ?? String(e)); }
    try { deactivateKeepAwake('anna-model-install'); } catch { /* optional */ }
    lock.current = false; setWorking(false); setProgress(null); setLink(''); setVersion(v => v + 1); onChanged(); dataEvents.emit();
  };
  const opts = (): I.InstallOptions => ({ onProgress: (done, total) => setProgress({ done, total }), beforeSwap: engine.unloadModel });

  const fromLink = () => {
    let parsed; try { parsed = I.parseModelUrl(link); } catch (e: any) { Alert.alert('Check the link', e?.message ?? String(e)); return; }
    Alert.alert('Download this model?', `${parsed.fileName}\n\nModels are large (often 1–3 GB). Use Wi-Fi, keep Anna open and the screen on until it finishes. A model you already have is kept until the new one is checked.`, [
      { text: 'Cancel', style: 'cancel' }, { text: 'Download', onPress: () => guarded(() => I.installFromUrl(modelStore, link, opts())) }]);
  };
  const fromFile = async () => {
    try {
      const r = await DocumentPicker.getDocumentAsync({ type: '*/*', copyToCacheDirectory: true }); if (r.canceled) return;
      const a = r.assets[0];
      guarded(() => I.installFromPickedFile(modelStore, { uri: a.uri, name: a.name, size: a.size ?? null }, opts()));
    } catch (e: any) { Alert.alert('Could not open the file', e?.message ?? String(e)); }
  };
  const remove = () => Alert.alert('Remove the AI model?', 'Anna will stop writing answers until a model is installed again. Your chats and memories are not affected.', [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Remove', style: 'destructive', onPress: () => guarded(async () => { await engine.unloadModel(); I.removeInstalledModels(modelStore); }) }]);

  return (<>
    <H2>Install or change the AI model</H2>
    <Card>
      <Text style={{ fontSize: 14 }}>{name ? `Installed: ${name}${size ? ` (${gb(size)})` : ''}` : 'No model installed yet.'}</Text>
      <Mute style={{ marginTop: 6 }}>Anna runs a small language model on your iPhone. It works offline once installed. Smaller models (under about 3 GB) are safest on an iPhone 15. Anna keeps one model at a time.</Mute>
      {progress && (<>
        <Bar value={progress.total ? progress.done / progress.total : 0} />
        <Mute style={{ marginTop: 4 }}>{progress.total ? `${gb(progress.done)} of ${gb(progress.total)}` : `${gb(progress.done)} downloaded`}</Mute></>)}
      {working && !progress && <Mute style={{ marginTop: 8 }}>Working… keep Anna open.</Mute>}
      <Btn label="Import a .gguf file from Files" onPress={fromFile} />
      <Field label="Or download from a link (https://… .gguf)" value={link} onChangeText={setLink} placeholder="https://…/model-Q4_K_M.gguf" />
      <Btn ghost label="Download from link" onPress={fromLink} />
      {!!name && <Btn danger label="Remove installed model" onPress={remove} />}
      <Mute style={{ marginTop: 8 }}>The on-device model only runs in the installed Anna app (development build), not in Expo Go.</Mute>
    </Card>
  </>);
}
