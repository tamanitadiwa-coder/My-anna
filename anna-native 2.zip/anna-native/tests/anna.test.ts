import { test } from 'node:test';
import assert from 'node:assert/strict';
import { makeDb, freshBrain } from './testDb';
import { migrate, integrityCheck, LATEST_VERSION, DatabaseTooNewError } from '../src/db/migrations';
import * as B from '../src/brain/brainService';
import { createBackup, restoreBackup, restoreWithSafetyNet, validateBackup, BackupError } from '../src/backup/backupCore';
import { sha256 } from '../src/util/sha256';
import { createHash } from 'node:crypto';

const count = async (db: any, t: string) => (await db.getFirstAsync(`SELECT COUNT(*) c FROM ${t}`)).c;

test('sha256 matches node crypto (incl. unicode)', () => {
  for (const s of ['', 'abc', 'Anna’s Brain — ünïcode 😀'.repeat(20)])
    assert.equal(sha256(s), createHash('sha256').update(s).digest('hex'));
});

test('migrations: fresh DB reaches latest version, is idempotent, rejects newer DB', async () => {
  const db = makeDb(); const r = await migrate(db);
  assert.deepEqual(r, { from: 0, to: LATEST_VERSION });
  assert.deepEqual(await migrate(db), { from: LATEST_VERSION, to: LATEST_VERSION });
  assert.equal((await integrityCheck(db)).ok, true);
  db.raw.exec(`PRAGMA user_version = ${LATEST_VERSION + 1}`);
  await assert.rejects(() => migrate(db), DatabaseTooNewError);
});

test('migrations keep existing user data', async () => {
  const db = makeDb(); await migrate(db); B.setBrainDb(db);
  await B.addMemory({ category: 'preferences', content: 'I like tea', status: 'confirmed' });
  await migrate(db);
  assert.equal(await count(db, 'brain_memories'), 1);
});

test('save → persists across a "restart" (new connection to same file)', async () => {
  const path = `/tmp/anna-test-${Date.now()}.db`;
  let db = makeDb(path); await migrate(db); B.setBrainDb(db); await B.initBrain();
  await B.addMemory({ category: 'preferences', content: 'I prefer paying bills at the start of the month', status: 'confirmed', source: 'taught' });
  db.raw.close();
  db = makeDb(path); await migrate(db); B.setBrainDb(db); await B.initBrain();
  const m = await B.listMemories();
  assert.equal(m.length, 1); assert.match(m[0].content, /paying bills/);
});

test('memory: validation, duplicates, edit, delete, temporary expiry', async () => {
  const db = await freshBrain(); await B.initBrain();
  await assert.rejects(() => B.addMemory({ category: 'about', content: '   ', status: 'confirmed' }), B.ValidationError);
  await assert.rejects(() => B.addMemory({ category: 'nope' as any, content: 'x', status: 'confirmed' }), B.ValidationError);
  const a = await B.addMemory({ category: 'about', content: 'I live in Cape Town', status: 'confirmed' });
  const b = await B.addMemory({ category: 'about', content: 'i live in cape town', status: 'confirmed' });
  assert.equal(a, b); assert.equal(await count(db, 'brain_memories'), 1);
  await B.updateMemory(a, { content: 'I live in Cape Town, South Africa', status: 'assumption' });
  assert.equal((await B.listMemories())[0].status, 'assumption');
  const t = await B.addMemory({ category: 'goals', content: 'Finish report this week', status: 'temporary', ttlDays: 7 });
  db.raw.exec(`UPDATE brain_memories SET expires_at=1 WHERE id='${t}'`);
  await B.initBrain();
  assert.equal((await B.listMemories({ category: 'goals' })).length, 0);
  await B.deleteMemory(a); assert.equal((await B.listMemories()).length, 0);
});

test('assumptions are never silently promoted and are labelled for the model', async () => {
  await freshBrain(); await B.initBrain();
  await B.addMemory({ category: 'finances', content: 'Maybe I get paid on the 25th', status: 'assumption', source: 'inferred' });
  const got = await B.retrieveRelevant('when do I get paid');
  assert.equal(got[0].status, 'assumption');
  assert.match(B.buildPromptContext(got), /UNCONFIRMED ASSUMPTION/);
  assert.equal(B.proposeFromText('I think I might prefer mornings').suggestedStatus, 'assumption');
});

test('retrieval: relevant memory found, deleted memory not retrieved, instructions always apply', async () => {
  await freshBrain(); await B.initBrain();
  const bills = await B.addMemory({ category: 'finances', content: 'I pay my bills at the beginning of the month', status: 'confirmed' });
  await B.addMemory({ category: 'preferences', content: 'I like jazz music', status: 'confirmed' });
  await B.addMemory({ category: 'instructions', content: 'Always consider upcoming commitments when I ask how much I can spend', status: 'confirmed' });
  const r = await B.retrieveRelevant('when should I pay bills');
  assert.ok(r.some(m => m.id === bills)); assert.ok(r.some(m => m.category === 'instructions')); assert.ok(!r.some(m => /jazz/.test(m.content)));
  await B.deleteMemory(bills);
  assert.ok(!(await B.retrieveRelevant('when should I pay bills')).some(m => m.id === bills));
});

test('feedback is stored and changes ranking; "dont_remember" removes non-confirmed memory only', async () => {
  const db = await freshBrain(); await B.initBrain();
  const good = await B.addMemory({ category: 'preferences', content: 'I like coffee in the morning', status: 'confirmed' });
  const bad = await B.addMemory({ category: 'preferences', content: 'I like coffee at night', status: 'confirmed' });
  const guess = await B.addMemory({ category: 'about', content: 'Maybe likes coffee a lot', status: 'assumption' });
  await B.recordFeedback({ rating: 'helpful', memoryIds: [good] });
  await B.recordFeedback({ rating: 'incorrect', memoryIds: [bad] });
  await B.recordFeedback({ rating: 'dont_remember', memoryIds: [guess, bad] });
  assert.equal(await count(db, 'brain_feedback'), 3);
  const ids = (await B.listMemories()).map(m => m.id);
  assert.ok(!ids.includes(guess)); assert.ok(ids.includes(bad)); // confirmed facts need an explicit delete
  const r = await B.retrieveRelevant('coffee');
  assert.equal(r[0].id, good);
  const p = await B.recordFeedback({ rating: 'remember', answerText: 'I prefer difficult tasks in the morning' });
  assert.equal(p?.category, 'routines'); // proposal only: nothing saved silently
  assert.equal((await B.listMemories()).length, 2);
  await assert.rejects(() => B.recordFeedback({ rating: 'bogus' as any }), B.ValidationError);
});

test('timeline comes from real events, never contains memory text', async () => {
  await freshBrain(); await B.initBrain();
  await B.addMemory({ category: 'finances', content: 'SECRET-SALARY-DETAIL', status: 'confirmed' });
  const tl = await B.getTimeline();
  assert.ok(tl.length >= 2); assert.equal(tl[tl.length - 1].day, 1);
  assert.ok(!JSON.stringify(tl).includes('SECRET'));
});

test('stats/progress are honest when there is no data', async () => {
  await freshBrain(); await B.initBrain();
  const s = await B.getStats(); assert.equal(s.memories, 0); assert.deepEqual(s.tasks, { total: 0, done: 0 }); assert.equal(s.records, 0);
  const p = await B.getProgress(); assert.ok(p.every(x => x.value === null));
});

test('backup → restore (replace) brings data back intact, incl. conversations', async () => {
  const db = await freshBrain(); await B.initBrain();
  await B.addMemory({ category: 'goals', content: 'Grow sales', status: 'confirmed' });
  db.raw.exec(`INSERT INTO conversations VALUES('c1','Hi',1,1); INSERT INTO messages VALUES('m1','c1','user','hello',NULL,1);`);
  const snap = JSON.parse(JSON.stringify(await createBackup(db, 'full'))); // via JSON, like a real file
  await B.deleteAllAnnaData();
  assert.equal(await count(db, 'brain_memories'), 0); assert.equal(await count(db, 'messages'), 0);
  const counts = await restoreBackup(db, snap, 'replace');
  assert.equal(counts.messages, 1);
  assert.equal((await B.listMemories())[0].content, 'Grow sales'); assert.equal(await count(db, 'messages'), 1);
  assert.equal((await integrityCheck(db)).ok, true);
});

test('validation rejects tampered, truncated, wrong-format and too-new backups', async () => {
  const db = await freshBrain(); await B.initBrain();
  await B.addMemory({ category: 'about', content: 'x', status: 'confirmed' });
  const good = JSON.parse(JSON.stringify(await createBackup(db, 'full')));
  assert.doesNotThrow(() => validateBackup(good));
  const tampered = JSON.parse(JSON.stringify(good)); tampered.tables.brain_memories[0].content = 'edited';
  assert.throws(() => validateBackup(tampered), /damaged/);
  const truncated = JSON.parse(JSON.stringify(good)); delete truncated.tables.messages;
  assert.throws(() => validateBackup(truncated), BackupError);
  assert.throws(() => validateBackup({ hello: 1 }), /not an Anna backup/);
  assert.throws(() => validateBackup(null), BackupError);
  assert.throws(() => validateBackup({ ...good, schemaVersion: 99 }), /newer version/);
});

test('FAILED restore leaves existing data untouched (transaction rollback)', async () => {
  const db = await freshBrain(); await B.initBrain();
  await B.addMemory({ category: 'about', content: 'keep me', status: 'confirmed' });
  const snap = JSON.parse(JSON.stringify(await createBackup(db, 'full')));
  // valid checksum, but second row violates a CHECK constraint → must roll back the whole restore
  const bad = JSON.parse(JSON.stringify(snap));
  bad.tables.brain_memories.push({ ...bad.tables.brain_memories[0], id: 'zzz', status: 'invalid-status' });
  const { sha256: h } = await import('../src/util/sha256');
  bad.checksum = h(JSON.stringify({ schemaVersion: bad.schemaVersion, scope: bad.scope, tables: bad.tables }));
  await assert.rejects(() => restoreBackup(db, bad, 'replace'));
  const m = await B.listMemories(); assert.equal(m.length, 1); assert.equal(m[0].content, 'keep me');
  // orphan message (foreign key) also rolls back
  const orphan = JSON.parse(JSON.stringify(snap));
  orphan.tables.messages.push({ id: 'x', conversation_id: 'missing', role: 'user', content: 'hi', memory_ids: null, created_at: 1 });
  orphan.checksum = h(JSON.stringify({ schemaVersion: orphan.schemaVersion, scope: orphan.scope, tables: orphan.tables }));
  await assert.rejects(() => restoreBackup(db, orphan, 'replace'));
  assert.equal((await B.listMemories()).length, 1);
});

test('safety net: snapshot is saved before restore; if saving fails nothing changes', async () => {
  const db = await freshBrain(); await B.initBrain();
  await B.addMemory({ category: 'about', content: 'original', status: 'confirmed' });
  const other = JSON.parse(JSON.stringify(await createBackup(db, 'full')));
  await B.deleteMemory((await B.listMemories())[0].id);
  await B.addMemory({ category: 'about', content: 'current', status: 'confirmed' });
  let saved: any = null;
  await restoreWithSafetyNet(db, other, 'replace', async s => { saved = s; });
  assert.equal(saved.tables.brain_memories[0].content, 'current');
  assert.equal((await B.listMemories())[0].content, 'original');
  await assert.rejects(() => restoreWithSafetyNet(db, saved, 'replace', async () => { throw new Error('disk full'); }), /disk full/);
  assert.equal((await B.listMemories())[0].content, 'original');
});

test('brain-only backup/restore does not touch conversations; merge keeps newer local data', async () => {
  const db = await freshBrain(); await B.initBrain();
  await B.addMemory({ category: 'about', content: 'one', status: 'confirmed' });
  db.raw.exec(`INSERT INTO conversations VALUES('c1','Hi',1,1);`);
  const payload = JSON.parse(JSON.stringify(await B.getBrainBackupPayload()));
  assert.equal(payload.scope, 'brain'); assert.equal(payload.tables.conversations, undefined);
  await B.addMemory({ category: 'about', content: 'two', status: 'confirmed' });
  const noSnap = async () => {};
  await B.restoreBrainPayload(payload, 'merge', noSnap);
  assert.equal((await B.listMemories()).length, 2); assert.equal(await count(db, 'conversations'), 1);
  await B.restoreBrainPayload(payload, 'replace', noSnap);
  assert.equal((await B.listMemories()).length, 1); assert.equal(await count(db, 'conversations'), 1);
});

test('privacy: clear conversations keeps memories; reset personalisation keeps facts; delete all wipes', async () => {
  const db = await freshBrain(); await B.initBrain();
  await B.addMemory({ category: 'about', content: 'fact', status: 'confirmed' });
  await B.addMemory({ category: 'preferences', content: 'pref', status: 'confirmed' });
  db.raw.exec(`INSERT INTO conversations VALUES('c1','Hi',1,1); INSERT INTO messages VALUES('m1','c1','user','hello',NULL,1);`);
  await B.clearConversationHistory();
  assert.equal(await count(db, 'messages'), 0); assert.equal(await count(db, 'conversations'), 0); assert.equal(await count(db, 'brain_memories'), 2);
  await B.resetPersonalisation();
  assert.deepEqual((await B.listMemories()).map(m => m.content), ['fact']);
  await B.deleteAllAnnaData();
  assert.equal(await count(db, 'brain_memories'), 0);
  const types = (await db.getAllAsync<{ type: string }>('SELECT type FROM brain_events')).map(e => e.type).sort();
  assert.deepEqual(types, ['brain_created', 'model_status']); // history of the old data is gone
});

test('clearMemories removes only the selected ones', async () => {
  await freshBrain(); await B.initBrain();
  const a = await B.addMemory({ category: 'about', content: 'a', status: 'confirmed' });
  await B.addMemory({ category: 'about', content: 'b', status: 'confirmed' });
  const c = await B.addMemory({ category: 'goals', content: 'c', status: 'confirmed' });
  assert.equal(await B.clearMemories([a, c]), 2);
  assert.deepEqual((await B.listMemories()).map(m => m.content), ['b']);
  assert.equal(await B.clearMemories([]), 0);
});

test('search treats % and _ literally', async () => {
  await freshBrain(); await B.initBrain();
  await B.addMemory({ category: 'about', content: 'discount is 50%', status: 'confirmed' });
  await B.addMemory({ category: 'about', content: 'plain text', status: 'confirmed' });
  assert.equal((await B.listMemories({ q: '%' })).length, 1);
});

import * as chat from '../src/chat/chatService';
test('chat: conversation persists across restart, ordered, tolerant of bad memory_ids', async () => {
  const path = `/tmp/anna-chat-${Date.now()}.db`;
  let db = makeDb(path); await migrate(db);
  const id = await chat.createConversation(db, 'Hello Anna, how are you today? This title is long enough to be cut');
  await chat.addMessage(db, id, 'user', 'hello');
  await chat.addMessage(db, id, 'assistant', 'hi!', ['m1', 'm2']);
  await chat.addMessage(db, id, 'system', 'notice');
  db.raw.close();
  db = makeDb(path); await migrate(db);
  const cid = await chat.latestConversationId(db); assert.equal(cid, id);
  const msgs = await chat.listMessages(db, id);
  assert.deepEqual(msgs.map(m => m.role), ['user', 'assistant', 'system']);
  assert.deepEqual(chat.parseIds(msgs[1].memory_ids), ['m1', 'm2']);
  assert.deepEqual(chat.parseIds('not json'), []); assert.deepEqual(chat.parseIds(null), []);
  await assert.rejects(() => chat.addMessage(db, 'no-such-conversation', 'user', 'x')); // foreign key protects integrity
});
