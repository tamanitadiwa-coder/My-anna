// Test adapter: runs Anna's real SQL on Node's built-in SQLite so logic is tested without a phone.
import { DatabaseSync } from 'node:sqlite';
import type { Db } from '../src/db/types';
import { migrate } from '../src/db/migrations';
import { setBrainDb } from '../src/brain/brainService';

const norm = (p: any[]) => p.map(v => (v === undefined ? null : v));
export function makeDb(path = ':memory:'): Db & { raw: DatabaseSync } {
  const raw = new DatabaseSync(path); raw.exec('PRAGMA foreign_keys = ON;');
  return {
    raw,
    async execAsync(sql) { raw.exec(sql); },
    async runAsync(sql, ...p) { const r = raw.prepare(sql).run(...norm(p)); return { changes: Number(r.changes) }; },
    async getFirstAsync<T>(sql: string, ...p: any[]) { return (raw.prepare(sql).get(...norm(p)) as T) ?? null; },
    async getAllAsync<T>(sql: string, ...p: any[]) { return raw.prepare(sql).all(...norm(p)) as T[]; },
    async withTransactionAsync(fn) {
      raw.exec('BEGIN');
      try { await fn(); raw.exec('COMMIT'); } catch (e) { raw.exec('ROLLBACK'); throw e; }
    },
  };
}
export async function freshBrain() { const db = makeDb(); await migrate(db); setBrainDb(db); return db; }
