// Stage 2–4 tests: restore safety fixes, Tasks, Money, Business, and local-model installation logic.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { makeDb, freshBrain } from './testDb';
import { migrate, MIGRATIONS } from '../src/db/migrations';
import * as B from '../src/brain/brainService';
import { createBackup, restoreBackup, extractBrainOnly, validateBackup, BackupError, wipeAll } from '../src/backup/backupCore';
import { sha256 } from '../src/util/sha256';
import { parseAmountToCents, formatCents } from '../src/util/money';
import { addMonths, parseDateInput, startOfDay, addDays } from '../src/util/dates';
import * as T from '../src/tasks/taskService';
import * as M from '../src/money/moneyService';
import * as BZ from '../src/business/businessService';
import * as I from '../src/ai/modelInstaller';

const count = async (db: any, t: string) => (await db.getFirstAsync(`SELECT COUNT(*) c FROM ${t}`)).c;
const clone = <T,>(x: T): T => JSON.parse(JSON.stringify(x));
const reseal = (p: any) => { p.checksum = sha256(JSON.stringify({ schemaVersion: p.schemaVersion, scope: p.scope, tables: p.tables })); return p; };
const D = (y: number, m: number, d: number, h = 12) => new Date(y, m - 1, d, h).getTime();

// ---------------- restore safety fixes ----------------
test('merge restore never overwrites a NEWER local edit, but does take a newer backup edit', async () => {
  const db = await freshBrain(); await B.initBrain();
  const id = await B.addMemory({ category: 'about', content: 'original', status: 'confirmed' });
  const snap = clone(await createBackup(db, 'brain'));
  await new Promise(r => setTimeout(r, 5));
  await B.updateMemory(id, { content: 'newer local edit' });
  await restoreBackup(db, snap, 'merge');
  assert.equal((await B.listMemories())[0].content, 'newer local edit');
  // now the opposite: the backup holds the newer version
  const older = clone(await createBackup(db, 'brain'));
  older.tables.brain_memories[0].content = 'edited elsewhere'; older.tables.brain_memories[0].updated_at += 1000; reseal(older);
  await restoreBackup(db, older, 'merge');
  assert.equal((await B.listMemories())[0].content, 'edited elsewhere');
});

test('full merge restore keeps local-only chat messages (no cascade delete)', async () => {
  const db = await freshBrain(); await B.initBrain();
  db.raw.exec(`INSERT INTO conversations VALUES('c1','Hi',1,1); INSERT INTO messages VALUES('m1','c1','user','from backup',NULL,1);`);
  const full = clone(await createBackup(db, 'full'));
  db.raw.exec(`INSERT INTO messages VALUES('m2','c1','user','LOCAL ONLY',NULL,2);`);
  await restoreBackup(db, full, 'merge');
  assert.equal(await count(db, 'messages'), 2);
});

test('Brain-only restore (replace) cannot touch chats, tasks, money or business data', async () => {
  const db = await freshBrain(); await B.initBrain();
  await B.addMemory({ category: 'about', content: 'brain fact', status: 'confirmed' });
  const brainSnap = clone(await B.getBrainBackupPayload());
  await B.addMemory({ category: 'about', content: 'added later', status: 'confirmed' });
  db.raw.exec(`INSERT INTO conversations VALUES('c1','Hi',1,1); INSERT INTO messages VALUES('m1','c1','user','hello',NULL,1);`);
  await T.addTask(db, { title: 'Call supplier' });
  await M.addTransaction(db, { kind: 'expense', amountCents: 5000 }); await M.addBill(db, { name: 'Rent', amountCents: 90000, dueAt: D(2026, 12, 1) });
  await M.setBudget(db, 'Food', 200000); await BZ.addRecord(db, { kind: 'sale', description: 'Order', amountCents: 10000 });
  let saved: any = null;
  await B.restoreBrainPayload(brainSnap, 'replace', async s => { saved = s; });
  assert.deepEqual((await B.listMemories()).map(m => m.content), ['brain fact']);
  for (const t of ['conversations', 'messages', 'tasks', 'transactions', 'bills', 'budgets', 'business_records']) assert.equal(await count(db, t), 1, t);
  assert.ok(saved.tables.tasks && saved.tables.business_records); // the safety snapshot covers everything
  await assert.rejects(() => B.restoreBrainPayload(brainSnap, 'replace', async () => { throw new Error('disk full'); }), /disk full/);
});

test('extractBrainOnly turns a full backup into a valid Brain-only backup; tampering is still caught', async () => {
  const db = await freshBrain(); await B.initBrain();
  await B.addMemory({ category: 'about', content: 'x', status: 'confirmed' });
  db.raw.exec(`INSERT INTO conversations VALUES('c1','Hi',1,1);`); await T.addTask(db, { title: 'secret task' });
  const full = clone(await createBackup(db, 'full'));
  const brain = extractBrainOnly(full);
  assert.equal(brain.scope, 'brain'); assert.doesNotThrow(() => validateBackup(brain));
  assert.deepEqual(Object.keys(brain.tables).sort(), ['brain_events', 'brain_feedback', 'brain_memories', 'brain_meta']);
  assert.ok(!JSON.stringify(brain).includes('secret task'));
  const bad = clone(full); bad.tables.brain_memories[0].content = 'edited';
  assert.throws(() => extractBrainOnly(bad), /damaged/);
});

test('an old (schema 1) backup still restores, and replace never wipes the newer modules', async () => {
  const db = await freshBrain(); await B.initBrain();
  await B.addMemory({ category: 'about', content: 'old fact', status: 'confirmed' });
  const v1 = clone(await createBackup(db, 'full'));
  for (const t of ['tasks', 'transactions', 'bills', 'budgets', 'business_records', 'app_settings']) delete v1.tables[t];
  v1.schemaVersion = 1; reseal(v1);
  assert.doesNotThrow(() => validateBackup(v1));
  await T.addTask(db, { title: 'keep me' }); await B.addMemory({ category: 'about', content: 'new fact', status: 'confirmed' });
  await restoreBackup(db, v1, 'replace');
  assert.deepEqual((await B.listMemories()).map(m => m.content), ['old fact']);
  assert.equal(await count(db, 'tasks'), 1);
  // a file claiming schema 1 but carrying v2 tables is rejected
  const liar = clone(await createBackup(db, 'full')); liar.schemaVersion = 1; reseal(liar);
  assert.throws(() => validateBackup(liar), BackupError);
});

test('full backup includes the new modules; round trip and wipe', async () => {
  const db = await freshBrain(); await B.initBrain();
  await T.addTask(db, { title: 'a' }); await M.setCurrency(db, 'R'); await M.addTransaction(db, { kind: 'income', amountCents: 123456 });
  await BZ.addRecord(db, { kind: 'invoice', description: 'Job', amountCents: 5000, party: 'Acme' });
  const snap = clone(await createBackup(db, 'full'));
  await wipeAll(db);
  for (const t of ['tasks', 'transactions', 'business_records', 'app_settings']) assert.equal(await count(db, t), 0);
  await restoreBackup(db, snap, 'replace');
  assert.equal(await M.getCurrency(db), 'R'); assert.equal((await M.listTransactions(db))[0].amount_cents, 123456);
  assert.equal((await BZ.listRecords(db))[0].party, 'Acme');
});

test('migration 2 upgrades an existing v1 database without losing data', async () => {
  const db = makeDb(); await db.execAsync(MIGRATIONS[0].sql); db.raw.exec('PRAGMA user_version = 1');
  db.raw.exec(`INSERT INTO brain_memories VALUES('m','about','kept','confirmed','manual',1,1,NULL,0,0,0,NULL)`);
  assert.deepEqual(await migrate(db), { from: 1, to: MIGRATIONS[MIGRATIONS.length - 1].version });
  assert.equal(await count(db, 'brain_memories'), 1); assert.equal(await count(db, 'tasks'), 0);
});

// ---------------- helpers ----------------
test('amounts: parse what people type, format for display', () => {
  const ok: [string, number][] = [['1250', 125000], ['1,250.50', 125050], ['R 1 250', 125000], ['12,5', 1250], ['1.250,75', 125075], ['0.99', 99], ['1,250', 125000], ['$ 3', 300]];
  for (const [i, c] of ok) assert.equal(parseAmountToCents(i), c, i);
  for (const bad of ['', 'abc', '0', '-5', '1.234', '1e9', '99999999999999']) assert.equal(parseAmountToCents(bad), null, bad);
  assert.equal(formatCents(125050), '1,250.50'); assert.equal(formatCents(5, 'R'), 'R0.05'); assert.equal(formatCents(-100000), '-1,000.00');
});

test('dates: month maths clamps to month end, bad dates rejected', () => {
  assert.equal(new Date(addMonths(D(2026, 1, 31), 1)).getDate(), 28);
  assert.equal(new Date(addMonths(D(2026, 12, 15), 1)).getMonth(), 0);
  assert.equal(parseDateInput('2026-02-30'), null); assert.equal(parseDateInput('tomorrow'), null);
  assert.equal(new Date(parseDateInput('2026-03-04')!).getDate(), 4);
});

// ---------------- Tasks ----------------
test('tasks: validate, no duplicates, complete/undo, order, summary, brain stats', async () => {
  const db = await freshBrain(); await B.initBrain();
  await assert.rejects(() => T.addTask(db, { title: '   ' }), /enter a task/);
  await assert.rejects(() => T.addTask(db, { title: 'x', priority: 'urgent' as any }), /priority/);
  const now = D(2026, 6, 10);
  const late = await T.addTask(db, { title: 'Pay supplier', dueAt: addDays(now, -2) });
  const today = await T.addTask(db, { title: 'Send quote', dueAt: startOfDay(now), priority: 'high' });
  const none = await T.addTask(db, { title: 'Tidy shelf' });
  assert.equal(await T.addTask(db, { title: 'tidy SHELF' }), none); assert.equal(await count(db, 'tasks'), 3);
  assert.deepEqual((await T.listTasks(db)).map(t => t.id), [late, today, none]);
  assert.deepEqual(await T.taskSummary(db, now), { open: 3, done: 0, overdue: 1, dueToday: 1 });
  await T.setTaskCompleted(db, late, true);
  assert.deepEqual((await T.listTasks(db, 'done')).map(t => t.id), [late]);
  assert.equal((await B.getStats()).tasks!.done, 1);
  const p = (await B.getProgress()).find(x => x.key === 'tasks')!; assert.equal(p.value, 1 / 3);
  await T.setTaskCompleted(db, late, false); assert.equal((await T.listTasks(db, 'done')).length, 0);
  await T.updateTask(db, none, { title: 'Tidy the shelf', priority: 'low' }); assert.equal((await T.listTasks(db)).find(t => t.id === none)!.title, 'Tidy the shelf');
  await T.deleteTask(db, none); await assert.rejects(() => T.setTaskCompleted(db, none, true), /no longer exists/);
});

// ---------------- Money ----------------
test('money: transactions, month summary, categories ignore other months', async () => {
  const db = await freshBrain(); const now = D(2026, 6, 15);
  await M.addTransaction(db, { kind: 'income', amountCents: 500000, occurredAt: D(2026, 6, 1) });
  await M.addTransaction(db, { kind: 'expense', amountCents: 12000, category: 'Food', occurredAt: D(2026, 6, 3) });
  await M.addTransaction(db, { kind: 'expense', amountCents: 8000, category: 'food', occurredAt: D(2026, 6, 9) });
  await M.addTransaction(db, { kind: 'expense', amountCents: 99999, category: 'Food', occurredAt: D(2026, 5, 30) }); // last month
  const s = await M.monthSummary(db, now);
  assert.equal(s.income, 500000); assert.equal(s.expense, 20000); assert.equal(s.net, 480000);
  assert.deepEqual(s.byCategory.map(c => [c.category.toLowerCase(), c.total]), [['food', 20000]]);
  await assert.rejects(() => M.addTransaction(db, { kind: 'expense', amountCents: 0 }), /greater than zero/);
  await assert.rejects(() => M.addTransaction(db, { kind: 'expense', amountCents: 1.5 }), /greater than zero/);
  await assert.rejects(() => M.addTransaction(db, { kind: 'gift' as any, amountCents: 100 }), /income or expense/);
});

test('bills: paying records one expense, rolls monthly bills forward, refuses double payment, rolls back on error', async () => {
  const db = await freshBrain(); const now = D(2026, 6, 10);
  const rent = await M.addBill(db, { name: 'Rent', amountCents: 900000, dueAt: D(2026, 6, 1), repeatMonthly: true });
  await M.addBill(db, { name: 'Phone', amountCents: 30000, dueAt: D(2026, 6, 12) });
  assert.deepEqual(await M.billSummary(db, now), { unpaid: 2, unpaidCents: 930000, overdue: 1, dueWithin7Days: 1 });
  await M.markBillPaid(db, rent, { recordExpense: true, now });
  await assert.rejects(() => M.markBillPaid(db, rent, { recordExpense: true, now }), /already/);
  assert.equal(await count(db, 'transactions'), 1);
  const open = await M.listBills(db); assert.equal(open.length, 2);
  assert.equal(new Date(open.find(b => b.name === 'Rent')!.due_at).getMonth(), 6); // July
  // failure inside the transaction (impossible amount) leaves the bill unpaid
  db.raw.exec(`PRAGMA foreign_keys=ON`);
  const bad = await M.addBill(db, { name: 'Odd', amountCents: 100, dueAt: D(2026, 7, 1) });
  db.raw.exec(`CREATE TRIGGER fail_tx BEFORE INSERT ON transactions BEGIN SELECT RAISE(ABORT,'boom'); END;`);
  await assert.rejects(() => M.markBillPaid(db, bad, { recordExpense: true, now }), /boom/);
  assert.equal((await M.listBills(db)).some(b => b.id === bad), true);
});

test('budgets: one per category, spending counted for this month only, over-budget flagged', async () => {
  const db = await freshBrain(); const now = D(2026, 6, 15);
  const a = await M.setBudget(db, 'Food', 100000); assert.equal(await M.setBudget(db, 'food', 150000), a); assert.equal(await count(db, 'budgets'), 1);
  await M.addTransaction(db, { kind: 'expense', amountCents: 120000, category: 'FOOD', occurredAt: D(2026, 6, 2) });
  await M.addTransaction(db, { kind: 'expense', amountCents: 999, category: 'Food', occurredAt: D(2026, 5, 2) });
  const [st] = await M.budgetStatus(db, now);
  assert.equal(st.spent, 120000); assert.equal(st.remaining, 30000); assert.equal(st.over, false);
  await M.addTransaction(db, { kind: 'expense', amountCents: 40000, category: 'food', occurredAt: D(2026, 6, 20) });
  assert.equal((await M.budgetStatus(db, now))[0].over, true);
  await assert.rejects(() => M.setBudget(db, 'Food', 0), /greater than zero/);
});

test('brain stats count finance + business records once the modules have data', async () => {
  const db = await freshBrain(); await B.initBrain();
  await M.addTransaction(db, { kind: 'income', amountCents: 100 }); await BZ.addRecord(db, { kind: 'sale', description: 's', amountCents: 100 });
  assert.equal((await B.getStats()).records, 2);
});

// ---------------- Business ----------------
test('business: cash-basis profit, outstanding invoices, overdue count', async () => {
  const db = await freshBrain(); const now = D(2026, 6, 20);
  await BZ.addRecord(db, { kind: 'sale', description: 'Walk-in', amountCents: 100000, occurredAt: D(2026, 6, 5) });
  await BZ.addRecord(db, { kind: 'expense', description: 'Stock', amountCents: 30000, occurredAt: D(2026, 6, 6) });
  const inv = await BZ.addRecord(db, { kind: 'invoice', description: 'Website', party: 'Acme', amountCents: 200000, occurredAt: D(2026, 6, 1), dueAt: D(2026, 6, 15) });
  let s = await BZ.businessSummary(db, now);
  assert.deepEqual(s, { revenue: 100000, expenses: 30000, profit: 70000, outstandingCount: 1, outstandingCents: 200000, overdueCount: 1 });
  await BZ.markInvoicePaid(db, inv, now);
  s = await BZ.businessSummary(db, now);
  assert.equal(s.revenue, 300000); assert.equal(s.outstandingCents, 0);
  assert.equal((await BZ.businessSummary(db, D(2026, 7, 5))).revenue, 0); // counted in the month it was paid
  await assert.rejects(() => BZ.markInvoicePaid(db, inv), /already paid/);
  const sale = (await BZ.listRecords(db, 'sale'))[0].id; await assert.rejects(() => BZ.markInvoicePaid(db, sale), /Only invoices/);
  await assert.rejects(() => BZ.addRecord(db, { kind: 'sale', description: '', amountCents: 100 }), /description/);
});

// ---------------- Local AI model installation ----------------
class FakeStore implements I.ModelStore {
  files = new Map<string, { size: number; magic: string }>(); free: number | null = 10 * I.GB; announced: number | null = null;
  failDownload = false; failRename: string | null = null; payload = { size: 800 * I.MB, magic: 'GGUF' }; ops: string[] = [];
  freeBytes() { return this.free; }
  listFiles() { return [...this.files.keys()]; }
  sizeOf(n: string) { return this.files.get(n)?.size ?? null; }
  remove(n: string) { this.files.delete(n); }
  rename(a: string, b: string) { if (this.failRename === b) { this.failRename = null; throw new Error('rename failed'); } if (this.files.has(b)) throw new Error('exists'); const f = this.files.get(a); if (!f) throw new Error('missing'); this.files.delete(a); this.files.set(b, f); this.ops.push(`${a}->${b}`); }
  readMagic(n: string) { return this.files.get(n)?.magic ?? null; }
  async contentLength() { return this.announced; }
  async download(_u: string, into: string, onBytes: (n: number) => void) {
    onBytes(1); if (this.failDownload) { this.files.set(into, { size: 10 * I.MB, magic: 'GGUF' }); throw new Error('network lost'); }
    this.files.set(into, { ...this.payload }); onBytes(this.payload.size);
  }
  async importPicked(_s: string, into: string) { this.files.set(into, { ...this.payload }); }
}
const LINK = 'https://huggingface.co/org/repo/resolve/main/Tiny-Q4_K_M.gguf?download=true';

test('model link and file-name validation', () => {
  assert.deepEqual(I.parseModelUrl(LINK), { url: LINK, fileName: 'Tiny-Q4_K_M.gguf' });
  for (const bad of ['http://x.com/a.gguf', 'ftp://x.com/a.gguf', 'https://user:pw@x.com/a.gguf', 'https://x.com/a.bin', 'not a link', 'https://x.com/', 'https://x.com/..%2Fa.gguf'])
    assert.throws(() => I.parseModelUrl(bad), I.ModelInstallError, bad);
  assert.throws(() => I.safeModelFileName('../evil.gguf')); assert.throws(() => I.safeModelFileName('a b.gguf')); assert.equal(I.safeModelFileName('ok-1.2.GGUF'), 'ok-1.2.GGUF');
});

test('install from link: success, progress reported, only the final model remains', async () => {
  const s = new FakeStore(); s.announced = 800 * I.MB; const seen: number[] = []; let unloaded = 0;
  const r = await I.installFromUrl(s, LINK, { onProgress: n => seen.push(n), beforeSwap: async () => { unloaded++; } });
  assert.equal(r.fileName, 'Tiny-Q4_K_M.gguf'); assert.deepEqual(s.listFiles(), ['Tiny-Q4_K_M.gguf']); assert.equal(unloaded, 1); assert.ok(seen.includes(800 * I.MB));
});

test('install refuses when storage is too small, before downloading anything', async () => {
  const s = new FakeStore(); s.announced = 2 * I.GB; s.free = 1 * I.GB;
  await assert.rejects(() => I.installFromUrl(s, LINK), /Not enough free storage/); assert.equal(s.files.size, 0);
  s.announced = null; s.free = 2 * I.GB; await assert.rejects(() => I.installFromUrl(s, LINK), /Not enough free storage/); // unknown size = cautious
  s.free = null; s.announced = 800 * I.MB; await assert.doesNotReject(() => I.installFromUrl(s, LINK)); // unmeasurable free space does not block
});

test('failed or wrong downloads leave the existing model untouched and clean up', async () => {
  const s = new FakeStore(); s.files.set('Old.gguf', { size: 700 * I.MB, magic: 'GGUF' }); s.announced = 800 * I.MB;
  s.failDownload = true; await assert.rejects(() => I.installFromUrl(s, LINK), /did not finish/);
  assert.deepEqual(s.listFiles(), ['Old.gguf']);
  s.failDownload = false; s.payload = { size: 500 * I.MB, magic: 'GGUF' }; await assert.rejects(() => I.installFromUrl(s, LINK), /incomplete/); // size mismatch vs announced
  s.announced = null; s.payload = { size: 800 * I.MB, magic: 'ZIPX' }; await assert.rejects(() => I.installFromUrl(s, LINK), /not a GGUF/);
  s.payload = { size: 10 * I.MB, magic: 'GGUF' }; await assert.rejects(() => I.installFromUrl(s, LINK), /not an AI model/);
  assert.deepEqual(s.listFiles(), ['Old.gguf']);
});

test('installing a new model replaces the old one; same-name reinstall keeps the old if the swap fails', async () => {
  const s = new FakeStore(); s.files.set('Old.gguf', { size: 700 * I.MB, magic: 'GGUF' }); s.announced = 800 * I.MB;
  await I.installFromUrl(s, LINK); assert.deepEqual(s.listFiles(), ['Tiny-Q4_K_M.gguf']);
  s.failRename = 'Tiny-Q4_K_M.gguf'; // swap cannot be completed
  await assert.rejects(() => I.installFromUrl(s, LINK), /previous model was kept/);
  assert.deepEqual(s.listFiles(), ['Tiny-Q4_K_M.gguf']); assert.equal(s.sizeOf('Tiny-Q4_K_M.gguf'), 800 * I.MB);
});

test('leftovers from a crash: .part removed, interrupted swap repaired', () => {
  const s = new FakeStore(); s.files.set('a.gguf.part', { size: 1, magic: 'GGUF' }); s.files.set('Model.gguf.old', { size: 700 * I.MB, magic: 'GGUF' });
  I.cleanupLeftovers(s); assert.deepEqual(s.listFiles(), ['Model.gguf']);
  s.files.set('x.gguf.old', { size: 1, magic: 'GGUF' }); I.cleanupLeftovers(s); assert.deepEqual(s.listFiles(), ['Model.gguf']); // a model exists, so .old is dropped
});

test('import a picked file, and remove the installed model', async () => {
  const s = new FakeStore();
  await I.installFromPickedFile(s, { uri: 'file:///cache/My-Model.gguf', name: 'My-Model.gguf', size: 800 * I.MB });
  assert.deepEqual(s.listFiles(), ['My-Model.gguf']);
  await assert.rejects(() => I.installFromPickedFile(s, { uri: 'file:///c/x.txt', name: 'x.txt' }), /\.gguf/);
  I.removeInstalledModels(s); assert.equal(s.files.size, 0);
  assert.equal(I.bigModelWarning(4 * I.GB) !== null, true); assert.equal(I.bigModelWarning(1 * I.GB), null);
});
