# Anna — personal AI assistant (private, on-device)

Anna keeps everything on your iPhone: chats, memories, backups. No cloud, no accounts, no paid AI.

## Run Anna on your iPhone for free (preview mode)
You need: a Windows laptop, your iPhone 15, and both on the same Wi-Fi.

1. Install Node.js (the "LTS" version, free): https://nodejs.org  — accept all defaults, then restart your laptop.
2. Unzip `anna-project.zip` somewhere easy, e.g. `C:\Anna`.
3. Open that folder, click the address bar, type `cmd`, press Enter. A black window opens.
4. Type `npm install` and press Enter. Wait until it finishes (a few minutes).
5. Type `npm run check` and press Enter. You should see `# pass 41` and `# fail 0`. (This tests Anna's database, backups, tasks, money, business and model-install logic.)
6. Type `npx expo start` and press Enter. A QR code appears.
7. On your iPhone, install **Expo Go** from the App Store (free). Open the iPhone Camera, point it at the QR code, tap the banner. Expo may ask you to sign in with a free Expo account.
8. If it cannot connect, stop (Ctrl+C) and run `npx expo start --tunnel` instead.

In preview mode the Chat, Brain, Tasks, Money, Business, Data, memory and backup features work. **The on-device AI model cannot run in Expo Go** — Anna will tell you clearly that no model is available instead of pretending to answer.

## Installing the real app with the AI model (later)
This needs a "development build", which on iPhone requires either a Mac with Xcode (free Apple ID works, apps expire after 7 days) or an Apple Developer account (about $99/year) with Expo's cloud build. Nothing in this project requires you to pay for the preview stage above.

## Adding the AI model (in the installed app)
Open the **Data** tab → *Install or change the AI model*. Either import a `.gguf` file you saved in the Files app, or paste an `https://` link to a `.gguf` file and tap Download. Use Wi-Fi and keep Anna open. Smaller models (under about 3 GB) are safest on an iPhone 15. A model you already have is only replaced after the new one is checked.
