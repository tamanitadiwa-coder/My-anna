# Anna — status after Stage 2–4 work (re-verified against the uploaded project)

## VERIFIED BY AUTOMATED TESTS (on a computer, not on an iPhone)
`npm run test` runs 41 tests (19 original + 22 new), all passing:
- Database: versioned migrations (v1 → v2 upgrade keeps data), refuses newer data, integrity check
- Brain: memories, duplicates, expiry, retrieval, feedback, privacy controls, honest statistics
- Backup/restore: create, validate (tampered / truncated / wrong file / too new / old schema), replace, merge, rollback on failure, safety snapshot
- Brain-only restore: cannot touch chats, tasks, money or business data (tested)
- Tasks, Money (transactions, bills, budgets), Business (sales, expenses, invoices) logic
- Local AI model installation logic (link and file-name checks, free-space check, safe swap, failure leaves the old model, crash recovery) using a fake file store

## TYPE-CHECKED
- Logic layer (database, brain, backup, chat, tasks, money, business, model installer, all tests): TypeScript strict, no errors.
- Screens: checked only against hand-written stand-ins for React Native / Expo (those packages could not be installed offline). `npm run check` on your laptop is the real check.

## IMPLEMENTED BUT NOT TESTED (needs the real app on an iPhone)
- How every screen looks and feels (Chat, Brain, Tasks, Money, Business, Data), keyboards, animations
- Saving / sharing / picking backup files (expo-file-system, expo-sharing, expo-document-picker)
- Local AI: loading a .gguf with llama.rn, streaming, memory, battery
- Model install on the phone: "Import from Files", "Download from link" (uses File.downloadFileAsync, looked up at run time; progress is estimated from the growing file), GGUF header read, keep-awake during install

## NOT IMPLEMENTED YET
- Chat does not yet read your tasks / money / business data when answering (the Brain only counts them)
- Cancelling a download in progress; resuming an interrupted download (it restarts)
- Excluding the model file from iCloud/iTunes backups (needs a native setting)
- Recurring tasks, editing money/business entries (delete and re-add for now), charts, CSV export
- Dark mode (light only)

## BLOCKED
- Installing on iPhone with the AI model: needs a Mac + Xcode or an Apple Developer account (see README)

## DECISIONS
- Navigation: custom bottom tabs in src/App.tsx. Expo Router is not installed or used; AGENTS.md used to say otherwise and now matches the app.
- Money is stored as whole cents. Business uses cash basis (sale counts on its day; invoice counts when marked paid).
- Anna keeps one AI model at a time; a new one replaces the old only after it is checked.
